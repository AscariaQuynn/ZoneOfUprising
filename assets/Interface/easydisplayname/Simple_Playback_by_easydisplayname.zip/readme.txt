You are allowed to use these buttons for personal or non-commercial use. You may edit these buttons, but you may not claim them as your own. You are not required to link back to the buttons, but it is a nice gesture.

Buttons made by:
http://easydisplayname.deviantart.com/
