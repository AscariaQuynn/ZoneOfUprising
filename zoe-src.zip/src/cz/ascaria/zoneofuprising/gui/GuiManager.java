/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.gui;

import com.jme3.app.state.AppStateManager;
import com.jme3.network.ClientStateListener;
import com.jme3.scene.Node;
import cz.ascaria.zoneofuprising.Main;
import cz.ascaria.zoneofuprising.ZoneOfUprising;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import tonegod.gui.core.Screen;

/**
 *
 * @author Ascaria Quynn
 */
public class GuiManager {

    public Screen screen;

    private List<LayoutInitListener> initListeners = new CopyOnWriteArrayList<LayoutInitListener>();

    private ZoneOfUprising app;
    private AppStateManager stateManager;
    private Node guiNode;

    private Map<Class<?extends Layout>, Layout> layouts;

    public GuiManager(ZoneOfUprising app, AppStateManager stateManager, Node guiNode) {
        this.app = app;
        this.stateManager = stateManager;
        this.guiNode = guiNode;

        screen = new Screen(app);

        layouts = new HashMap<Class<?extends Layout>, Layout>();
    }

    public void initialize() {
        screen.setUseUIAudio(true);
        guiNode.addControl(screen);
    }
    
    public void cleanup() {
        guiNode.removeControl(screen);
    }

    public void addLayoutInitialized(LayoutInitListener listener) {
        initListeners.add(listener);
    }

    /**
     * Which layout to show.
     * @param layout
     * @return true if layout was shown, false on fail
     */
    public boolean show(Class<?extends Layout> layout) {
        // Create layout
        if(!layouts.containsKey(layout)) {
            initLayout(layout);
        }
        // Destroy all layouts
        for(Layout l : layouts.values()) {
            if(l.isOpened()) {
                l.close();
            }
        }
        // Show specified layout
        for(Class<?extends Layout> key : layouts.keySet()) {
            if(layout.equals(key)) {
                layouts.get(key).open();
                return true;
            }
        }
        return false;
    }

    private boolean initLayout(Class<?extends Layout> layout) {
        try {
            // Try to create layout
            Layout instance = layout.newInstance();
            instance.initialize(app, stateManager);
            instance.setGuiManager(this);
            instance.setScreen(screen);
            layouts.put(layout, instance);
            // Fire initialized event
            for(LayoutInitListener listener : initListeners ) {
                listener.layoutInitialized(instance);
            }
            return true;
        } catch (Exception ex) {
            Main.LOG.log(Level.SEVERE, null, ex);
            return false;
        }
    }

    /**
     * Get specific layout.
     * @param layout
     * @return 
     */
    public Layout getLayout(Class<?extends Layout> layout) {
        // Create layout
        if(!layouts.containsKey(layout)) {
            initLayout(layout);
        }
        return layouts.get(layout);
    }

}
