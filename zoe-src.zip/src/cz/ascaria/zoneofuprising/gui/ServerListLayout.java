/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.gui;

import com.jme3.input.event.MouseButtonEvent;
import com.jme3.math.Vector2f;
import cz.ascaria.zoneofuprising.Main;
import cz.ascaria.zoneofuprising.ZoneOfUprising;
import cz.ascaria.network.client.ClientLoginManager;
import cz.ascaria.zoneofuprising.gui.custom.DefaultAlertBox;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import tonegod.gui.controls.buttons.ButtonAdapter;
import tonegod.gui.controls.lists.SelectList;
import tonegod.gui.controls.windows.Window;

/**
 *
 * @author Ascaria Quynn
 */
public class ServerListLayout extends BaseLayout {

    public ClientLoginManager clientLoginManager;

    private Window win;

    public boolean isOpened() {
        return null != win;
    }

    @Override
    public void open() {
        super.open();
        check();
        if(isOpened()) {
            close();
        }

        // Create window
        win = new Window(screen, new Vector2f(15f, 15f), new Vector2f(800f, 600f));
        win.setWindowIsMovable(false);
        win.setIsResizable(false);
        win.setGlobalAlpha(0.9f);
        win.setWindowTitle("Zone of Uprising Server List");
        win.centerToParent();
        screen.addElement(win);

        // Server selection
        final SelectList selectList = new SelectList(screen, new Vector2f(15f, 50f), new Vector2f(400f, 300f)) {
            @Override
            public void onChange() {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };
        selectList.addListItem("localhost", "localhost");
        for(int i = 1; i <= 5; i++) {
            selectList.addListItem("10.0.0." + i, "10.0.0." + i);
        }
        selectList.addSelectedIndex(0);
        win.addChild(selectList);        

        // Join server button
        ButtonAdapter joinServer = new ButtonAdapter(screen, new Vector2f(50f, 400f)) {
            @Override
            public void onButtonMouseLeftUp(MouseButtonEvent evt, boolean toggled) {
                // Get vars
                List<SelectList.ListItem> items = selectList.getSelectedListItems();
                // Try to connect to server
                if(!items.isEmpty() && !clientLoginManager.isConnected()) {
                    SelectList.ListItem host = items.get(0);
                    try {
                        clientLoginManager.connect((String)host.getValue(), ServerListLayout.this.app.getServerPort());
                    } catch (IOException ex) {
                        Main.LOG.log(Level.SEVERE, null, ex);
                        DefaultAlertBox alert = new DefaultAlertBox(screen, Vector2f.ZERO);
                        alert.setWindowTitle("Connection error");
                        alert.setMsg(ex.getLocalizedMessage() + "\nMaybe wrong host or there is no server running?");
                        alert.showAsModal(false);
                        screen.addElement(alert);
                        alert.centerToParent();
                    }
                }
            }
        };
        joinServer.setText("Join Server");
        win.addChild(joinServer);

        // Add server button
        ButtonAdapter addServer = new ButtonAdapter(screen, new Vector2f(170f, 400f)) {
            @Override
            public void onButtonMouseLeftUp(MouseButtonEvent evt, boolean toggled) {
                AddServerLayout asl = (AddServerLayout)guiManager.getLayout(AddServerLayout.class);
                asl.selectList = selectList;
                asl.open();
            }
        };
        addServer.setText("Add Server");
        win.addChild(addServer);

        // Back button
        ButtonAdapter back = new ButtonAdapter(screen, new Vector2f(290f, 400f)) {
            @Override
            public void onButtonMouseLeftUp(MouseButtonEvent evt, boolean toggled) {
                guiManager.show(MainMenuLayout.class);
            }
        };
        back.setText("Back");
        win.addChild(back);
    }

    @Override
    public void close() {
        super.close();
        if(null != win) {
            win.hide();
            screen.removeElement(win);
            win = null;
        }
    }
}
