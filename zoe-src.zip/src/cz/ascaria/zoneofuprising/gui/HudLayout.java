/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.gui;

import com.jme3.input.KeyInput;
import com.jme3.input.event.MouseButtonEvent;
import com.jme3.math.Vector2f;
import com.jme3.system.AppSettings;
import cz.ascaria.network.client.ClientLoginManager;
import cz.ascaria.network.messages.ChatMessage;
import cz.ascaria.zoneofuprising.controls.UserInputControl;
import tonegod.gui.controls.buttons.Button;
import tonegod.gui.controls.buttons.ButtonAdapter;
import tonegod.gui.controls.extras.ChatBox;
import tonegod.gui.controls.text.TextField;
import tonegod.gui.controls.windows.Panel;

/**
 *
 * @author Ascaria Quynn
 */
public class HudLayout extends BaseLayout {

    public ClientLoginManager clientLoginManager;
    public UserInputControl userControl;

    private ChatBox chatBox;
    private Panel dashBoard;

    private boolean isFocusedChat = false;
    private boolean msgSent = false;
    private boolean isOpened = false;

    public boolean isOpened() {
        return isOpened;
    }

    @Override
    public void open() {
        super.open();
        check();
        if(isOpened()) {
            close();
        }
        isOpened = true;

        // Get screen dimensions from settings
        AppSettings settings = app.getContext().getSettings();
        int width = settings.getWidth();
        int height = settings.getHeight();

        // Create chat window
        int chWidth = (int)(width / 3.5f);
        int chHeight = (int)(height / 2.5f);
        
        chatBox = new ChatBox(screen, "HudChat", new Vector2f(15f, height - chHeight - 90), new Vector2f(chWidth, chHeight)) {
            @Override
            public void onSendMsg(String msg) {
                if(clientLoginManager.isConnected()) {
                    clientLoginManager.client.send(new ChatMessage(msg));
                }
                msgSent = true;
                blurChat();
            }
        };
        chatBox.setGlobalAlpha(0.8f);
        chatBox.setSendKey(KeyInput.KEY_RETURN);
        chatBox.setIsResizable(false);
        chatBox.setIsMovable(false);
        screen.addElement(chatBox);

        // Create dashboard
        dashBoard = new Panel(screen, new Vector2f(width / 2 - 250, height - 75), new Vector2f(500f, 75f));
        screen.addElement(dashBoard);

        Button spotlights = new ButtonAdapter(screen, new Vector2f(5f, 5f)) {
            @Override
            public void onButtonMouseLeftUp(MouseButtonEvent evt, boolean toggled) {
                super.onButtonMouseLeftUp(evt, toggled);
                if(null != userControl) {
                    userControl.onAction("ToggleSpotLights", toggled, 1f/60f);
                }
            }
        };
        spotlights.setText("Spotlights");
        spotlights.setIsToggleButton(true);
        dashBoard.addChild(spotlights);

        Button pointlights = new ButtonAdapter(screen, new Vector2f(110f, 5f)) {
            @Override
            public void onButtonMouseLeftUp(MouseButtonEvent evt, boolean toggled) {
                super.onButtonMouseLeftUp(evt, toggled);
                if(null != userControl) {
                    userControl.onAction("TogglePointLights", toggled, 1f/60f);
                }
            }
        };
        pointlights.setText("Pointlights");
        pointlights.setIsToggleButton(true);
        dashBoard.addChild(pointlights);
    }

    @Override
    public void close() {
        super.close();
        if(null != chatBox) {
            isOpened = false;
            // Destroy chatbox
            chatBox.hide();
            screen.removeElement(chatBox);
            chatBox = null;
            // Destroy dashboard
            dashBoard.hide();
            screen.removeElement(dashBoard);
            dashBoard = null;
        }
    }

    public boolean isFocusedChat() {
        if(msgSent) {
            msgSent = false;
            return true;
        }
        return isFocusedChat;
    }

    public void focusChat() {
        TextField chatText = (TextField)screen.getElementById("HudChat:ChatInput");
        if(null != chatText) {
            chatText.setTabFocus();
            isFocusedChat = true;
        }
    }

    public void blurChat() {
        TextField chatText = (TextField)screen.getElementById("HudChat:ChatInput");
        if(null != chatText) {
            chatText.setText("");
            chatText.resetTabFocus();
            isFocusedChat = false;
        }
    }

    public void receiveMsg(String text) {
        if(isOpened()) {
            chatBox.receiveMsg(text);
        }
    }
}
