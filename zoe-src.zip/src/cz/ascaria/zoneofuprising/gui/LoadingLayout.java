/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.gui;

import com.jme3.font.BitmapFont;
import com.jme3.math.Vector2f;
import tonegod.gui.controls.text.Label;

/**
 *
 * @author Ascaria Quynn
 */
public class LoadingLayout extends BaseLayout {

    public Label label;

    public boolean isOpened() {
        return null != label;
    }

    @Override
    public void open() {
        super.open();
        check();
        if(isOpened()) {
            close();
        }

        label = new Label(screen, Vector2f.ZERO, new Vector2f(200f, 20f));
        label.setTextAlign(BitmapFont.Align.Center);
        label.setText("loading layout");
        label.centerToParent();
        screen.addElement(label);
    }

    @Override
    public void close() {
        super.close();
        if(null != label) {
            label.hide();
            screen.removeElement(label);
            label = null;
        }
    }
}
