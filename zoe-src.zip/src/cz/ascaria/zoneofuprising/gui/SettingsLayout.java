/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.gui;

import com.jme3.input.event.MouseButtonEvent;
import com.jme3.math.Vector2f;
import tonegod.gui.controls.buttons.ButtonAdapter;
import tonegod.gui.controls.windows.Window;

/**
 *
 * @author Ascaria Quynn
 */
public class SettingsLayout extends BaseLayout {

    private Window win;

    public boolean isOpened() {
        return null != win;
    }

    @Override
    public void open() {
        super.open();
        check();
        if(isOpened()) {
            close();
        }

        // Create window
        win = new Window(screen, new Vector2f(15f, 15f), new Vector2f(300f, 400f));
        win.setWindowIsMovable(false);
        win.setIsResizable(false);
        win.setGlobalAlpha(0.9f);
        win.setWindowTitle("Zone of Uprising Settings");
        win.centerToParent();
        screen.addElement(win);

        // Back button
        ButtonAdapter back = new ButtonAdapter(screen, new Vector2f(15f, 220f)) {
            @Override
            public void onButtonMouseLeftUp(MouseButtonEvent evt, boolean toggled) {
                guiManager.show(MainMenuLayout.class);
            }
        };
        back.setText("Back");
        win.addChild(back);
    }

    @Override
    public void close() {
        super.close();
        if(null != win) {
            win.hide();
            screen.removeElement(win);
            win = null;
        }
    }
}
