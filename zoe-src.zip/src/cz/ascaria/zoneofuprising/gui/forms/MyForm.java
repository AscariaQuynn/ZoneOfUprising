/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.gui.forms;

import java.util.HashMap;
import java.util.Map;
import tonegod.gui.controls.form.Form;
import tonegod.gui.controls.text.TextField;
import tonegod.gui.core.Element;
import tonegod.gui.core.ElementManager;

/**
 *
 * @author Ascaria Quynn
 */
abstract public class MyForm extends Form {

    private Map<String, Element> elems = new HashMap<String, Element>();

    public MyForm(ElementManager screen) {
        super(screen);
    }

    @Override
    public void addFormElement(Element element) {
        addFormElement(element.getUID(), element);
    }

    public void addFormElement(String name, Element element) {
        super.addFormElement(element);
        if(elems.containsKey(name)) {
            throw new IllegalArgumentException("Element with name '" + name + "' already exist.");
        }
        if(element instanceof TextField) {
            elems.put(name, element);
        }
    }

    @Override
    public void submitForm() {
        HashMap<String, String> values = new HashMap<String, String>();
        for(Map.Entry<String, Element> entry : elems.entrySet()) {
            values.put(entry.getKey(), entry.getValue().getText());
        }
        if(onValidate(values)) {
            onSuccess(values);
        } else {
            onError(values);
        }
    }

    abstract public boolean onValidate(HashMap<String, String> values);

    abstract public void onSuccess(HashMap<String, String> values);

    abstract public void onError(HashMap<String, String> values);
}
