/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.gui;

import com.jme3.app.state.AppStateManager;
import cz.ascaria.zoneofuprising.ZoneOfUprising;
import tonegod.gui.core.Screen;

/**
 *
 * @author Ascaria Quynn
 */
abstract public class BaseLayout implements Layout {

    protected AppStateManager stateManager;
    protected ZoneOfUprising app;
    protected GuiManager guiManager;
    protected Screen screen;

    public void initialize(ZoneOfUprising app, AppStateManager stateManager) {
        this.app = app;
        this.stateManager = stateManager;
    }

    public void setGuiManager(GuiManager guiManager) {
        this.guiManager = guiManager;
    }

    public void setScreen(Screen screen) {
        this.screen = screen;
    }

    public void open() {
        System.out.println(this.getClass().getSimpleName() + ".open() thread: " + Thread.currentThread());
    }

    public void close() {
        System.out.println(this.getClass().getSimpleName() + ".close() thread: " + Thread.currentThread());
    }
        

    protected void check() {
        if(null == app || null == stateManager) {
            throw new IllegalStateException("You must use initialize() first");
        }
        if(null == guiManager) {
            throw new IllegalStateException("You must use setGuiManager() first");
        }
        if(null == screen) {
            throw new IllegalStateException("You must use setScreen() first");
        }
    }
}
