/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.gui;

/**
 *
 * @author Ascaria Quynn
 */
public interface LayoutInitListener {
    /**
     * Called when layout is fully initialized.
     * @param layout 
     */
    public void layoutInitialized(Layout layout);
}
