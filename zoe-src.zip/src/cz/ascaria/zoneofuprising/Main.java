package cz.ascaria.zoneofuprising;

import com.jme3.system.JmeContext;
import cz.ascaria.zoneofuprising.utils.SettingsLoader;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.logging.Logger;

/**
 * Zone of Uprising.
 * @author Jaroslav Ascaria Svoboda
 */
public class Main {

    /** Logger for whole app */
    final public static Logger LOG = Logger.getLogger("cz.ascaria.zoneofuprising");

    /** Executor for whole app */
    final public static ScheduledThreadPoolExecutor executor = new ScheduledThreadPoolExecutor(4);

    /**
     * Zone of Uprising.
     * @param args 
     */
    public static void main(String[] args) {
        // default is not server
        boolean isServer = false;
        if(args.length > 0 && args[0].equals("-server")) {
            isServer = true;
        }

        // Run client or server
        if(isServer) {
            ZoneOfUprising server = new ZoneOfUprising(true);
            server.setSettings(new SettingsLoader().load());
            server.setPauseOnLostFocus(false);
            server.start(args.length > 1 && args[1].equals("-withhead") ? JmeContext.Type.Display : JmeContext.Type.Headless);
        } else {
            ZoneOfUprising client = new ZoneOfUprising(false);
            client.setSettings(new SettingsLoader().load());
            client.setPauseOnLostFocus(false);
            client.start(JmeContext.Type.Display);
        }
    }
}
