/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.input;

import com.jme3.collision.CollisionResult;
import com.jme3.collision.CollisionResults;
import com.jme3.cursors.plugins.JmeCursor;
import com.jme3.input.InputManager;
import com.jme3.input.KeyInput;
import com.jme3.input.MouseInput;
import com.jme3.input.controls.ActionListener;
import com.jme3.input.controls.AnalogListener;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.input.controls.MouseAxisTrigger;
import com.jme3.input.controls.MouseButtonTrigger;
import com.jme3.input.controls.Trigger;
import com.jme3.math.Ray;
import com.jme3.math.Vector2f;
import com.jme3.math.Vector3f;
import com.jme3.renderer.Camera;
import com.jme3.scene.Geometry;
import com.jme3.scene.Spatial;
import cz.ascaria.zoneofuprising.controls.SpaceShipControl;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

/**
 *
 * @author Ascaria Quynn
 */
public class ShipInputListener extends BaseInputListener implements ActionListener, AnalogListener {

    public LinkedList<Spatial> targetables;
    public Camera cam;
    public JmeCursor gunSight;
    public SpaceShipControl shipControl;
    //public HudController hudController;

    public float mouseSensivity = 1f;
    protected boolean mouseControlEnabled = false;
    protected boolean mouseRolling = false;

    protected HashMap<String, Trigger[]> triggers = new HashMap<String, Trigger[]>() {{
        put("ShipMoveUp", new Trigger[] { new KeyTrigger(KeyInput.KEY_Q) });
        put("ShipMoveDown", new Trigger[] { new KeyTrigger(KeyInput.KEY_E) });
        put("ShipMoveLeft", new Trigger[] { new KeyTrigger(KeyInput.KEY_A) });
        put("ShipMoveRight", new Trigger[] { new KeyTrigger(KeyInput.KEY_D) });
        put("ShipMoveForward", new Trigger[] { new KeyTrigger(KeyInput.KEY_W) });
        put("ShipMoveBackward", new Trigger[] { new KeyTrigger(KeyInput.KEY_S) });

        put("ShipYawLeft", new Trigger[] { new KeyTrigger(KeyInput.KEY_U) });
        put("ShipYawRight", new Trigger[] { new KeyTrigger(KeyInput.KEY_O) });
        put("ShipPitchUp", new Trigger[] { new KeyTrigger(KeyInput.KEY_K) });
        put("ShipPitchDown", new Trigger[] { new KeyTrigger(KeyInput.KEY_I) });
        put("ShipRollLeft", new Trigger[] { new KeyTrigger(KeyInput.KEY_J) });
        put("ShipRollRight", new Trigger[] { new KeyTrigger(KeyInput.KEY_L) });

        put("ShipYawRollLeftMouse", new Trigger[] { new MouseAxisTrigger(MouseInput.AXIS_X, true) });
        put("ShipYawRollRightMouse", new Trigger[] { new MouseAxisTrigger(MouseInput.AXIS_X, false) });
        put("ShipPitchUpMouse", new Trigger[] { new MouseAxisTrigger(MouseInput.AXIS_Y, false) });
        put("ShipPitchDownMouse", new Trigger[] { new MouseAxisTrigger(MouseInput.AXIS_Y, true) });

        put("ShipToggleMouseControlEnabled", new Trigger[] { new KeyTrigger(KeyInput.KEY_LCONTROL) });
        put("ShipToggleMouseRolling", new Trigger[] { new MouseButtonTrigger(MouseInput.BUTTON_MIDDLE) });

        put("ShipGunModeAll", new Trigger[] {
            new KeyTrigger(KeyInput.KEY_1)
        });
        put("ShipGunModeTurrets", new Trigger[] {
            new KeyTrigger(KeyInput.KEY_2)
        });
        put("ShipGunModeFixedGuns", new Trigger[] {
            new KeyTrigger(KeyInput.KEY_3)
        });

        put("ShipLockTarget", new Trigger[] { new MouseButtonTrigger(MouseInput.BUTTON_LEFT) });
        put("ShipUnlockTarget", new Trigger[] { new MouseButtonTrigger(MouseInput.BUTTON_RIGHT) });

        put("ShipFireKey", new Trigger[] { new KeyTrigger(KeyInput.KEY_SPACE) });
        put("ShipFireMouse", new Trigger[] { new MouseButtonTrigger(MouseInput.BUTTON_LEFT) });

        put("ShipClearForces", new Trigger[] { new KeyTrigger(KeyInput.KEY_C) });

        put("ShipToggleRotationControl", new Trigger[] { new KeyTrigger(KeyInput.KEY_B) });
        put("ShipToggleMovementControl", new Trigger[] { new KeyTrigger(KeyInput.KEY_V) });
    }};

    public ShipInputListener(InputManager inputManager) {
        super(inputManager);
    }

    /**
     * Should mouse control the ship?
     * @param mouseControlEnabled 
     */
    public void setMouseControlEnabled(boolean mouseControlEnabled) {
        this.mouseControlEnabled = mouseControlEnabled;
        inputManager.setCursorVisible(!mouseControlEnabled);
    }

    /**
     * Is mouse control for ship enabled?
     * @return 
     */
    public boolean isMouseControlEnabled() {
        return mouseControlEnabled;
    }

    public void registerInputs() {
        System.out.println("ShipInputListener registering inputs");
        for(Map.Entry<String, Trigger[]> entry : triggers.entrySet()) {
            inputManager.addMapping(entry.getKey(), entry.getValue());
        }
        inputManager.addListener(this, triggers.keySet().toArray(new String[triggers.keySet().size()]));
        // Set mouse cursor to aiming cursor
        if(null != gunSight) {
            inputManager.setMouseCursor(gunSight);
        }
    }

    public void clearInputs() {
        System.out.println("ShipInputListener clearing inputs");
        for(String key : triggers.keySet()) {
            inputManager.deleteMapping(key);
        }
        inputManager.removeListener(this);
        // Reset mouse cursor
        inputManager.setMouseCursor(null);
    }

    /**
     * Returns mouse aiming collisions.
     * @return 
     */
    public Geometry fireRay() {
        // Convert screen click to 3d position
        Vector2f click2d = inputManager.getCursorPosition();
        Vector3f click3d = cam.getWorldCoordinates(new Vector2f(click2d.x + 15, click2d.y + 15), 0f).clone();
        Vector3f dir = cam.getWorldCoordinates(new Vector2f(click2d.x + 15, click2d.y - 15), 1f).subtractLocal(click3d).normalizeLocal();
        // Aim the ray from the clicked spot forwards.
        Ray ray = new Ray(click3d, dir);
        // Reset results list.
        CollisionResults results = new CollisionResults();
        // Collect intersections between ray and all nodes in results list.
        for(Spatial targetable : targetables) {
            targetable.collideWith(ray, results);
        }
        // Get geometry
        CollisionResult closest = results.getClosestCollision();
        // Return results
        return null != closest ? closest.getGeometry() : null;
    }

    /**
     * @param name
     * @param isPressed
     * @param tpf 
     */
    public void onAction(String name, boolean isPressed, float tpf) {
        if(enabled && null != shipControl) {
            if(name.equals("ShipToggleMouseControlEnabled")) {
                setMouseControlEnabled(!isPressed);
            }
            if(mouseControlEnabled && name.equals("ShipToggleMouseRolling")) {
                mouseRolling = isPressed;
            }

            if(name.equals("ShipToggleRotationControl") && !isPressed) {
                shipControl.setRotationControl(!shipControl.isEnabledRotationControl());
            }
            if(name.equals("ShipToggleMovementControl") && !isPressed) {
                shipControl.setMovementControl(!shipControl.isEnabledMovementControl());
            }

            if(name.equals("ShipClearForces") && isPressed) {
                shipControl.setLinearVelocity(Vector3f.ZERO);
                shipControl.setAngularVelocity(Vector3f.ZERO);
            }

            if(name.equals("ShipGunModeAll") && isPressed) {
                shipControl.setGunMode(1);
            }
            if(name.equals("ShipGunModeTurrets") && isPressed) {
                shipControl.setGunMode(2);
            }
            if(name.equals("ShipGunModeFixedGuns") && isPressed) {
                shipControl.setGunMode(3);
            }

            if(name.equals("ShipLockTarget") && isPressed && !mouseControlEnabled) {
                Geometry target = fireRay();
                if(null != target) {
                    shipControl.lockTarget(target);
                    //hudController.lockTarget(target);
                }
            }
            if(name.equals("ShipUnlockTarget") && isPressed) {
                shipControl.lockTarget(null);
                //hudController.lockTarget(null);
            }

            if(name.equals("ShipFireKey") || (isMouseControlEnabled() && name.equals("ShipFireMouse"))) {
                // TODO: fire mode all-at-once, one-by-one, all turret's barrels at once or something like that
                if(isPressed) {
                    shipControl.fire();
                } else {
                    shipControl.cease();
                }
            }
        }
    }

    /**
     * @param name
     * @param value
     * @param tpf 
     */
    public void onAnalog(String name, float value, float tpf) {
        if(enabled && null != shipControl) {
            if(name.equals("ShipMoveUp")) {
                shipControl.ascent(value);
            }
            if(name.equals("ShipMoveDown")) {
                shipControl.ascent(-value);
            }
            if(name.equals("ShipMoveForward")) {
                shipControl.accelerate(value);
            }
            if(name.equals("ShipMoveBackward")) {
                shipControl.accelerate(-value);
            }
            if(name.equals("ShipMoveLeft")) {
                shipControl.strafe(value);
            }
            if(name.equals("ShipMoveRight")) {
                shipControl.strafe(-value);
            }

            if(name.equals("ShipYawLeft")) {
                shipControl.yaw(value);
            }
            if(name.equals("ShipYawRight")) {
                shipControl.yaw(-value);
            }
            if(name.equals("ShipRollLeft")) {
                shipControl.roll(-value);
            }
            if(name.equals("ShipRollRight")) {
                shipControl.roll(value);
            }
            if(name.equals("ShipPitchUp")) {
                shipControl.pitch(-value);
            }
            if(name.equals("ShipPitchDown")) {
                shipControl.pitch(value);
            }

            if(mouseControlEnabled && !mouseRolling && name.equals("ShipYawRollLeftMouse")) {
                shipControl.yaw(Math.min(0.02f, value) * mouseSensivity);
            }
            if(mouseControlEnabled && !mouseRolling && name.equals("ShipYawRollRightMouse")) {
                shipControl.yaw(Math.max(-0.02f, -value) * mouseSensivity);
            }
            if(mouseControlEnabled && mouseRolling && name.equals("ShipYawRollLeftMouse")) {
                shipControl.roll(Math.max(-0.02f, -value) * mouseSensivity);
            }
            if(mouseControlEnabled && mouseRolling && name.equals("ShipYawRollRightMouse")) {
                shipControl.roll(Math.min(0.02f, value) * mouseSensivity);
            }
            if(mouseControlEnabled && name.equals("ShipPitchUpMouse")) {
                shipControl.pitch(Math.max(-0.02f, -value) * mouseSensivity);
            }
            if(mouseControlEnabled && name.equals("ShipPitchDownMouse")) {
                shipControl.pitch(Math.min(0.02f, value) * mouseSensivity);
            }
        }
    }
}
