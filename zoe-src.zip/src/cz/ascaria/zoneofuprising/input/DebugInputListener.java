/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.input;

import com.jme3.input.InputManager;
import com.jme3.input.KeyInput;
import com.jme3.input.controls.ActionListener;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.renderer.Camera;
import com.jme3.util.BufferUtils;
import cz.ascaria.zoneofuprising.appstates.DebugAppState;

/**
 *
 * @author Ascaria Quynn
 */
public class DebugInputListener extends BaseInputListener implements ActionListener {

    public DebugAppState debugAppState;
    public Camera cam;

    public DebugInputListener(InputManager inputManager) {
        super(inputManager);
    }

    public void registerInputs() {
        inputManager.addMapping("DebugShowStats", new KeyTrigger(KeyInput.KEY_F5));
        inputManager.addMapping("DebugCameraPos", new KeyTrigger(KeyInput.KEY_F6));
        inputManager.addMapping("DebugMemory", new KeyTrigger(KeyInput.KEY_F7));
        inputManager.addListener(this, new String[] {
            "DebugShowStats",
            "DebugCameraPos",
            "DebugMemory"
        });
    }

    public void clearInputs() {
        inputManager.deleteMapping("DebugShowStats");
        inputManager.deleteMapping("DebugCameraPos");
        inputManager.deleteMapping("DebugMemory");
        inputManager.removeListener(this);
    }

    public void onAction(String name, boolean isPressed, float tpf) {
        if(isPressed) {
            if(name.equals("DebugShowStats")){
                debugAppState.toggleStats();
            }
            if(name.equals("DebugCameraPos")) {
                Vector3f loc = cam.getLocation();
                Quaternion rot = cam.getRotation();
                System.out.println("Camera Position: ("
                        + loc.x + ", " + loc.y + ", " + loc.z + ")");
                System.out.println("Camera Rotation: " + rot);
                System.out.println("Camera Direction: " + cam.getDirection());
            }
            if(name.equals("DebugMemory")) {
                BufferUtils.printCurrentDirectMemory(null);
            }
        }
    }
}
