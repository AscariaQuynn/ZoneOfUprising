/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.entities;

import com.jme3.asset.AssetManager;
import com.jme3.scene.Node;
import cz.ascaria.zoneofuprising.controls.FixedGunControl;
import cz.ascaria.zoneofuprising.controls.SpaceShipControl;
import cz.ascaria.zoneofuprising.controls.TurretControl;

/**
 *
 * @author Ascaria Quynn
 */
public class ShipBuilder implements EntityBuilder {

    protected AssetManager assetManager;
    protected String entityPath;

    public void initialize(AssetManager assetManager, String entityPath) {
        this.assetManager = assetManager;
        this.entityPath = entityPath;
    }

    /**
     * Builds whole space ship ready to be added to the level.
     * @return 
     */
    public Node buildEntity() {

        // Create ship
        SpaceShipFactory spaceShipFactory = new SpaceShipFactory(assetManager) {{
            engineSoundPath = "/Engine.ogg";
        }};
        Node spaceShip = spaceShipFactory.createShip(entityPath);
        SpaceShipControl shipControl = spaceShip.getControl(SpaceShipControl.class);
        shipControl.setGunMode(2);

        // Create lights
        LightsFactory lightsFactory = new LightsFactory();
        lightsFactory.createLights(spaceShip);

        // Create turrets
        TurretFactory turretFactory = new TurretFactory(assetManager);
        Node t1 = turretFactory.createTurret("/turret_2/scene_turret_2.j3o");
        Node t2 = turretFactory.createTurret("/turret_2/scene_turret_2.j3o");
        shipControl.addTurret(t1);
        shipControl.addTurret(t2);
        TurretControl tc1 = t1.getControl(TurretControl.class);
        TurretControl tc2 = t2.getControl(TurretControl.class);

        // Prepare projectiles
        ProjectileFactory projectileFactory = new ProjectileFactory(assetManager) {{
            modelPath = "/projectile_545/scene_projectile_545.j3o";
            gunshotSoundPath = "/Gun.ogg";
            impactSoundPath = "/Grenade.ogg";
        }};
        tc1.setProjectileFactory(projectileFactory, 100);
        tc2.setProjectileFactory(projectileFactory, 100);

        // Create fixed guns
        FixedGunFactory fixedGunFactory = new FixedGunFactory(assetManager);
        Node fg1 = fixedGunFactory.createFixedGun("/modelless_laser/scene_modelless_laser.j3o");
        Node fg2 = fixedGunFactory.createFixedGun("/modelless_laser/scene_modelless_laser.j3o");
        shipControl.addFixedGun(fg1);
        shipControl.addFixedGun(fg2);
        FixedGunControl fgc1 = fg1.getControl(FixedGunControl.class);
        FixedGunControl fgc2 = fg2.getControl(FixedGunControl.class);
        fgc1.setProjectileFactory(projectileFactory, 1);
        fgc2.setProjectileFactory(projectileFactory, 1);

        // Return completed ship
        return spaceShip;
    }
}
