/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.entities;

import com.jme3.effect.ParticleEmitter;
import com.jme3.scene.Node;
import com.jme3.scene.SceneGraphVisitor;
import com.jme3.scene.Spatial;
import cz.ascaria.zoneofuprising.controls.SpaceShipControl;

/**
 *
 * @author Ascaria Quynn
 */
public class SpaceShipVisitor implements SceneGraphVisitor {

    protected SpaceShipControl shipControl;

    public SpaceShipVisitor(SpaceShipControl shipControl) {
        this.shipControl = shipControl;
    }

    public void visit(Spatial spatial) {
        if(spatial instanceof Node && "TurretSlot".equals(spatial.getName())) {
            shipControl.addTurretSlot((Node)spatial);
        }
        if(spatial instanceof Node && "FixedSlot".equals(spatial.getName())) {
            shipControl.addFixedGunSlot((Node)spatial);
        }
        if(spatial instanceof ParticleEmitter && "EngineEmitter".equals(spatial.getName())) {
            shipControl.setEngineEmitter((ParticleEmitter)spatial);
        }
    }
}
