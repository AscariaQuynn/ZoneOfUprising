/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.entities;

import com.jme3.scene.Node;
import com.jme3.scene.SceneGraphVisitor;
import com.jme3.scene.Spatial;
import cz.ascaria.zoneofuprising.controls.FixedGunControl;

/**
 *
 * @author Ascaria Quynn
 */
public class FixedGunVisitor implements SceneGraphVisitor {

    protected FixedGunControl fixedGunControl;

    public FixedGunVisitor(FixedGunControl fixedGunControl) {
        this.fixedGunControl = fixedGunControl;
    }

    public void visit(Spatial spatial) {
        if(spatial.getName().equals("Barrel")) {
            fixedGunControl.addBarrel((Node)spatial);
        }
    }
}
