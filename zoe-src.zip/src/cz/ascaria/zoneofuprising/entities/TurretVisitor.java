/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.entities;

import com.jme3.scene.Node;
import com.jme3.scene.SceneGraphVisitor;
import com.jme3.scene.Spatial;
import cz.ascaria.zoneofuprising.controls.TurretControl;

/**
 *
 * @author Ascaria Quynn
 */
public class TurretVisitor implements SceneGraphVisitor {

    protected TurretControl turretControl;

    public TurretVisitor(TurretControl turretControl) {
        this.turretControl = turretControl;
    }

    public void visit(Spatial spatial) {
        if(spatial.getName().equals("Traverser")) {
            turretControl.setTraverser((Node)spatial);
        }
        if(spatial.getName().equals("Elevator")) {
            turretControl.setElevator((Node)spatial);
        }
        if(spatial.getName().equals("Barrel")) {
            turretControl.addBarrel((Node)spatial);
        }
    }
}
