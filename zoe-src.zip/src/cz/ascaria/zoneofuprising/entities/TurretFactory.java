/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.entities;

import com.jme3.asset.AssetManager;
import com.jme3.renderer.queue.RenderQueue;
import com.jme3.scene.Node;
import cz.ascaria.zoneofuprising.controls.TurretControl;

/**
 *
 * @author Ascaria Quynn
 */
public class TurretFactory {

    protected AssetManager assetManager;

    public TurretFactory(AssetManager assetManager) {
        this.assetManager = assetManager;
    }
    
    /**
     * Builds an turret.
     * @param projectilesNode projectiles will appear here
     * @param assetManager
     * @param path
     * @return 
     */
    public Node createTurret(String path) {
        // Load turret scene
        Node turret = (Node)assetManager.loadModel("Models/Turrets" + path);
        turret.setShadowMode(RenderQueue.ShadowMode.Cast);

        // Create turret control
        TurretControl turretControl = new TurretControl();
        turret.addControl(turretControl);
        // Prepare turret parts
        turret.depthFirstTraversal(new TurretVisitor(turretControl));

        // Return prepared turret
        return turret;
    }
}
