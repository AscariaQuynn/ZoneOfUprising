/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.entities;

import com.jme3.asset.AssetManager;
import com.jme3.scene.Node;

/**
 *
 * @author Ascaria Quynn
 */
public interface EntityBuilder {

    public void initialize(AssetManager assetManager, String entityPath);

    public Node buildEntity();
}
