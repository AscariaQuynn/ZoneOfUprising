/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.entities;

import com.jme3.asset.AssetManager;
import com.jme3.audio.AudioNode;
import com.jme3.bullet.collision.PhysicsCollisionObject;
import com.jme3.bullet.collision.shapes.CollisionShape;
import com.jme3.bullet.util.CollisionShapeFactory;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.renderer.queue.RenderQueue;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.scene.shape.Cylinder;
import cz.ascaria.zoneofuprising.controls.ProjectileControl;

/**
 *
 * @author Ascaria Quynn
 */
public class ProjectileFactory {

    public String modelPath = "/projectile_545/scene_projectile_545.j3o";
    public String gunshotSoundPath = "/Gun.ogg";
    public String impactSoundPath = "/Grenade.ogg";

    protected AssetManager assetManager;

    /**
     * @param assetManager
     * @param path
     */
    public ProjectileFactory(AssetManager assetManager) {
        this.assetManager = assetManager;
    }
    
    /**
     * Creates a projectile.
     * @return 
     */
    public Spatial createProjectile() {
        // Load projectile scene
        Node projectile = (Node)assetManager.loadModel("Models/Projectiles" + modelPath);
        projectile.setShadowMode(RenderQueue.ShadowMode.Cast);

        // Create collision shape
        CollisionShape shape = getCollisionShape((Geometry)projectile.getChild("Geometry"));

        // Create projectile control
        ProjectileControl projectileControl = new ProjectileControl(assetManager, shape, 0.01f);
        projectile.addControl(projectileControl);

        // Set collision groups
        projectileControl.setCollisionGroup(PhysicsCollisionObject.COLLISION_GROUP_04);
        projectileControl.addCollideWithGroup(PhysicsCollisionObject.COLLISION_GROUP_02);

        // Create impact sound
        projectileControl.impactSound = createImpactSound();
        projectile.attachChild(projectileControl.impactSound);

        // Return prepared projectile
        return projectile;
    }

    public Spatial createBeam() {
        float length = 1f;
        Vector3f scale = new Vector3f(1f, 1f, 600f);

        Material matCyl = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        matCyl.setColor("Color", new ColorRGBA(1f, 0.95f, 0.95f, 1f));
        matCyl.setColor("GlowColor", ColorRGBA.Red);

        // Create a glowing beam cylinder
        Cylinder cyl = new Cylinder(4, 4, 0.05f, length, true);
        Spatial beam = new Geometry("LaserBeam", cyl);
        beam.setLocalScale(scale);
        beam.setLocalTranslation(new Vector3f(0f, 0f, length / 2).mult(scale));
        beam.setMaterial(matCyl);


        // Return prepared beam
        return beam;
    }

    public AudioNode createGunshotSound() {
        AudioNode gunshot = new AudioNode(assetManager, "Sounds/Effects" + gunshotSoundPath, false);
        gunshot.setPositional(true);
        gunshot.setLooping(false);
        gunshot.setVolume(0.3f);
        return gunshot;
    }

    public AudioNode createImpactSound() {
        AudioNode impact = new AudioNode(assetManager, "Sounds/Effects" + impactSoundPath, false);
        impact.setName("ImpactSound");
        impact.setPositional(false);
        impact.setLooping(false);
        impact.setVolume(0.6f);
        return impact;
    }

    protected CollisionShape getCollisionShape(Geometry geometry) {
        CollisionShape shape = CollisionShapeFactory.createBoxShape(geometry);
        shape.setScale(Vector3f.UNIT_XYZ.mult(1f));
        return shape;
    }
}
