/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.entities;

import com.jme3.asset.AssetManager;
import com.jme3.audio.AudioNode;
import com.jme3.bullet.collision.shapes.CollisionShape;
import com.jme3.bullet.util.CollisionShapeFactory;
import com.jme3.renderer.queue.RenderQueue;
import com.jme3.scene.Node;
import cz.ascaria.zoneofuprising.Main;
import cz.ascaria.zoneofuprising.controls.SpaceShipControl;
import java.util.logging.Level;

/**
 *
 * @author Ascaria Quynn
 */
public class SpaceShipFactory {

    public String engineSoundPath = "/Engine.ogg";

    protected AssetManager assetManager;

    public SpaceShipFactory(AssetManager assetManager) {
        this.assetManager = assetManager;
    }

    /**
     * Builds an space ship.
     * @param assetManager
     * @param path
     * @return 
     */
    public Node createShip(String shipName) {
        // Load ship scene
        Node ship = (Node)assetManager.loadModel("Models/SpaceShips/" + shipName + "/model.j3o");
        ship.setShadowMode(RenderQueue.ShadowMode.Cast);
        // Create collision shape
        CollisionShape shape = getCollisionShape(shipName);
        // Create ship control
        SpaceShipControl shipControl = getShipControl(shape, (Float)ship.getUserData("Mass"));
        ship.addControl(shipControl);
        // Create ship sounds
        shipControl.engineSound = createEngineSound();
        ship.attachChild(shipControl.engineSound);
        // Prepare ship parts
        ship.depthFirstTraversal(new SpaceShipVisitor(shipControl));
        // Return prepared ship
        return ship;
    }

    public CollisionShape getCollisionShape(String shipName) {
        try {
            //return CollisionShapeFactory.createDynamicMeshShape((Node)assetManager.loadModel("Models/SpaceShips/" + shipName + "/collision.j3o"));
            CollisionShape boxShape = CollisionShapeFactory.createBoxShape((Node)assetManager.loadModel("Models/SpaceShips/" + shipName + "/collision.j3o"));
            boxShape.setMargin(1f);
            return boxShape;
        } catch(Exception e) {
            Main.LOG.log(Level.WARNING, "Collision model not found", e);
            return getBoxShape(shipName);
        }
    }

    public CollisionShape getBoxShape(String shipName) {
        return CollisionShapeFactory.createBoxShape((Node)assetManager.loadModel("Models/SpaceShips/" + shipName + "/model.j3o"));
    }

    protected SpaceShipControl getShipControl(CollisionShape shape, float mass) {
        SpaceShipControl shipControl = new SpaceShipControl(shape, mass);
        //<editor-fold defaultstate="collapsed" desc="Ship control setup">
        shipControl.setMovementPower(400f);
        shipControl.setRotationPower(600f);
        shipControl.setSleepingThresholds(0.01f, 0.01f);
        shipControl.setRotationControl(true);
        shipControl.setMovementControl(true);
        //</editor-fold>
        return shipControl;
    }

    public AudioNode createEngineSound() {
        AudioNode engine = new AudioNode(assetManager, "Sounds/Effects" + engineSoundPath, false);
        engine.setPositional(true);
        engine.setLooping(true);
        engine.setVolume(5f);
        return engine;
    }
}
