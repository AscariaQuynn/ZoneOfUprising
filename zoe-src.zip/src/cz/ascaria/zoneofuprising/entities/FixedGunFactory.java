/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.entities;

import com.jme3.asset.AssetManager;
import com.jme3.renderer.queue.RenderQueue;
import com.jme3.scene.Node;
import cz.ascaria.zoneofuprising.controls.FixedGunControl;

/**
 *
 * @author Ascaria Quynn
 */
public class FixedGunFactory {

    protected AssetManager assetManager;

    public FixedGunFactory(AssetManager assetManager) {
        this.assetManager = assetManager;
    }
    
    /**
     * Builds an turret.
     * @param projectilesNode projectiles will appear here
     * @param assetManager
     * @param path
     * @return 
     */
    public Node createFixedGun(String path) {
        // Load turret scene
        Node fixedGun = (Node)assetManager.loadModel("Models/FixedGuns" + path);
        fixedGun.setShadowMode(RenderQueue.ShadowMode.Cast);

        // Create turret control
        FixedGunControl fixedGunControl = new FixedGunControl();
        fixedGun.addControl(fixedGunControl);
        // Prepare turret parts
        fixedGun.depthFirstTraversal(new FixedGunVisitor(fixedGunControl));

        // Return prepared turret
        return fixedGun;
    }
}
