/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.entities;

import com.jme3.asset.AssetManager;
import com.jme3.math.FastMath;
import com.jme3.scene.Node;
import com.jme3.scene.SceneGraphVisitor;
import com.jme3.scene.Spatial;
import cz.ascaria.zoneofuprising.controls.SpaceShipControl;
import java.util.LinkedList;

/**
 *
 * @author Ascaria Quynn
 */
public class EnemyVisitor implements SceneGraphVisitor {

    protected AssetManager assetManager;
    protected Node shipsNode;
    protected LinkedList<Spatial> targetables;

    public EnemyVisitor(AssetManager assetManager, Node shipsNode, LinkedList<Spatial> targetables) {
        this.assetManager = assetManager;
        this.shipsNode = shipsNode;
        this.targetables = targetables;
    }

    public void visit(Spatial spatial) {

        // If player location is found by scenegraph visitor
        if(spatial instanceof Node && spatial.getName().equals("Enemy")) {

            // Ships' model paths
            String[] models = {
                "/dark_fighter_6",
                "/scifi_fighter_mk"
            };
            String path = models[FastMath.nextRandomInt(0, models.length - 1)];

            // Create ship
            SpaceShipFactory spaceShipFactory = new SpaceShipFactory(assetManager);
            Node spaceShip = spaceShipFactory.createShip(path);
            SpaceShipControl shipControl = spaceShip.getControl(SpaceShipControl.class);
            shipControl.setPhysicsLocation(spatial.getWorldTranslation().clone());
            shipControl.setPhysicsRotation(spatial.getWorldRotation().clone());
            shipControl.setMovementControl(true);
            shipControl.setLinearDamping(0.7f);
            shipControl.setKinematic(true);
            shipControl.setKinematicSpatial(false);

            // Add enemy's ship to the level
            shipsNode.attachChild(spaceShip);
            targetables.add(spaceShip);
        }
    }
}
