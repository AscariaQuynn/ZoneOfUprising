/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.entities;

import com.jme3.math.Vector3f;
import com.jme3.renderer.Camera;
import com.jme3.scene.Node;
import com.jme3.scene.SceneGraphVisitor;
import com.jme3.scene.Spatial;
import cz.ascaria.zoneofuprising.controls.DelayedCamera;
import cz.ascaria.zoneofuprising.utils.UserDataHelper;

/**
 *
 * @author Ascaria Quynn
 */
public class CamerasVisitor implements SceneGraphVisitor {
    
    protected Camera cam;

    public CamerasVisitor(Camera cam) {
        this.cam = cam;
    }

    /**
     * Add camera controls to various camera nodes.
     * @param spatial 
     */
    public void visit(Spatial spatial) {
        if(spatial instanceof Node && "DelayedCamera".equals(spatial.getName())) {
            spatial.addControl(new DelayedCamera(cam, 3f));
        }
    }
}
