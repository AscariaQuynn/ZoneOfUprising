/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.entities;

import com.jme3.scene.Node;
import com.jme3.scene.SceneGraphVisitor;
import com.jme3.scene.Spatial;

/**
 *
 * @author Ascaria Quynn
 */
public class PlayerVisitor implements SceneGraphVisitor {

    public Node player = new Node();

    public void visit(Spatial spatial) {
        // If player location is found by scenegraph visitor
        if(spatial instanceof Node && spatial.getName().equals("Player")) {
            // Add player's ship to the level
            player = (Node)spatial;
        }
    }
}
