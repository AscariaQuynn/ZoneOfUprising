/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising;

import com.jme3.app.Application;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial.CullHint;
import cz.ascaria.network.client.ClientLoginManager;
import cz.ascaria.network.messages.MessagesRegistrator;
import cz.ascaria.network.server.Console;
import cz.ascaria.network.server.ServerLoginManager;
import java.util.logging.Level;

/**
 * Zone of Uprising
 * @author Ascaria
 */
final public class ZoneOfUprising extends Application
{
    public static Thread renderThread;

    private boolean isServer;
    private int port = 6143;
    private Console console;

    private Node rootNode = new Node("Root Node");
    private Node guiNode = new Node("Gui Node");

    /**
     * Zone of Uprising.
     * @param isServer 
     */
    public ZoneOfUprising(boolean isServer) {
        super();
        this.isServer = isServer;
        ZoneOfUprising.renderThread = Thread.currentThread();
        System.out.println("ZoneOfUprising Current thread: " + ZoneOfUprising.renderThread);
    }

    public int getServerPort() {
        return port;
    }

    public Node getRootNode() {
        return rootNode;
    }
    
    public Node getGuiNode() {
        return guiNode;
    }
    
    @Override
    public void initialize()
    {
        super.initialize();

        guiNode.setQueueBucket(Bucket.Gui);
        guiNode.setCullHint(CullHint.Never);
        viewPort.attachScene(rootNode);
        guiViewPort.attachScene(guiNode);

        cam.setFrustumFar(1E7f);

        // Register all network messages once
        MessagesRegistrator.registerMessages();

        // Create server or client
        if(isServer) {
            runServer(port);
        } else {
            runClient();
        }
    }

    @Override
    public void update()
    {
        // makes sure to execute AppTasks
        super.update();

        if(speed > 0 && !paused) {
            float tpf = timer.getTimePerFrame() * speed;

            // update states
            stateManager.update(tpf);

            rootNode.updateLogicalState(tpf);
            guiNode.updateLogicalState(tpf);

            rootNode.updateGeometricState();
            guiNode.updateGeometricState();

            // render states
            stateManager.render(renderManager);
            renderManager.render(tpf, context.isRenderable());
            stateManager.postRender();        
        }
    }

    @Override
    public void destroy()
    {
        Main.executor.shutdown();
        super.destroy();
    }

    /**
     * Run server at specified port.
     * @param port 
     */
    public void runServer(int port) {
        console = Console.getInstance();
        console.show();

        console.print("Zone of Uprising Server version 0.1 pre alpha");

        try {
            ServerLoginManager serverLoginManager = new ServerLoginManager();
            serverLoginManager.setConsole(console);
            serverLoginManager.runServer(port);
            stateManager.attach(serverLoginManager);
        } catch (Exception ex) {
            Main.LOG.log(Level.SEVERE, null, ex);
            console.println(ex.getLocalizedMessage());
            System.exit(255);
        }
    }

    public void runClient() {
        stateManager.attach(new ClientLoginManager());
    }
}
