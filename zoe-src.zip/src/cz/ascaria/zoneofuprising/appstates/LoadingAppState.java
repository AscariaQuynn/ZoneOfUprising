/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.appstates;

import com.jme3.app.Application;
import com.jme3.app.state.AppStateManager;
import com.jme3.scene.Node;
import cz.ascaria.zoneofuprising.Main;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

/**
 *
 * @author Ascaria Quynn
 */
abstract public class LoadingAppState extends BaseAppState {

    private Future future;

    @Override
    public void initialize(AppStateManager stateManager, Application app)
    {
        super.initialize(stateManager, app);

        // Load model on another thread
        future = executor.schedule(new Callable<Node>() {
            public Node call() throws Exception {
                return onLoadModel();
            }
        }, 100, TimeUnit.MILLISECONDS);
    }

    @Override
    public void update(float tpf) {
        // If we are done
        if(null != future && future.isDone() && !future.isCancelled()) {
            try {
                // Get model from another thread
                Node model = (Node)future.get();
                Main.LOG.log(Level.INFO, "Model loaded: {0}", model);
                // Run defined event when loading is complete
                onLoadingComplete(model);
            } catch(Exception e) {
                future = null;
                System.out.println(e.getClass() + ": " + e.getMessage());
                Main.LOG.log(Level.SEVERE, e.getLocalizedMessage(), e);
            }
            if(null == future || future.isDone()) {
                // Automatically detach self
                stateManager.detach(this);
            }
        }
    }

    /**
     * Implement model loading procedure, then return model's Node.
     * It is done on another thread, so do not add model somewhere in this method.
     * @return 
     */
    abstract protected Node onLoadModel() throws Exception;

    /**
     * Implement what to do after loading is complete.
     * You can use levelAppState and physicsAppState, because you are on main thread.
     * @param model 
     */
    abstract protected void onLoadingComplete(Node model);
}
