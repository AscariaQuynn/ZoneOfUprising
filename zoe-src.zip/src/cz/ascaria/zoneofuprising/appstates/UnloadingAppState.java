/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.appstates;

/**
 *
 * @author Ascaria Quynn
 */
abstract public class UnloadingAppState extends BaseAppState {

    @Override
    public void update(float tpf) {
        onUnloadModel();
        stateManager.detach(this);
    }

    /**
     * Implement model unloading procedure.
     * You can use levelAppState and physicsAppState, because you are on main thread.
     * @return 
     */
    abstract protected void onUnloadModel();
}
