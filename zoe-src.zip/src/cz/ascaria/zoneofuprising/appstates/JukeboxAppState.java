/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.appstates;

import com.jme3.app.Application;
import com.jme3.app.state.AppStateManager;
import com.jme3.audio.AudioNode;
import com.jme3.audio.AudioSource;
import com.jme3.math.FastMath;

/**
 *
 * @author Ascaria Quynn
 */
public class JukeboxAppState extends BaseAppState
{
    // Music can't hurt, usually
    private AudioNode audioNode;
    private String[] jukebox = {
        "Sounds/Music/EarthChant.ogg",
        "Sounds/Music/SpaceDrums.ogg"
    };

    @Override
    public void initialize(AppStateManager stateManager, Application app) {
        super.initialize(stateManager, app);

        audioNode = new AudioNode(app.getAssetManager(), jukebox[FastMath.nextRandomInt(0, jukebox.length - 1)] , true);
        audioNode.setDirectional(false);
        audioNode.setLooping(false);
        audioNode.setVolume(0.0f);
        app.getAudioRenderer().playSource(audioNode);
        initialized = true;
    }

    @Override
    public void update(float tpf) {
        super.update(tpf);
        float v = audioNode.getVolume();
        if (v < 1f) {
            audioNode.setVolume(v + 0.001f);
        }
        if (audioNode.getStatus() == AudioSource.Status.Stopped) {
            audioNode.setVolume(0.0f);
            audioNode = new AudioNode(assetManager, jukebox[FastMath.nextRandomInt(0, jukebox.length - 1)], true);
            app.getAudioRenderer().playSource(audioNode);
        }
    }

    @Override
    public void cleanup()
    {
        initialized = false;
        audioNode.setVolume(0.0f);
        audioNode = null;
        super.cleanup();
    }
}
