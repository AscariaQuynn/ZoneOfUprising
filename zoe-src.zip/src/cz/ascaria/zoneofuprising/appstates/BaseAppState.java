/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.appstates;

import com.jme3.app.Application;
import com.jme3.app.state.AbstractAppState;
import com.jme3.app.state.AppStateManager;
import com.jme3.asset.AssetManager;
import com.jme3.input.InputManager;
import com.jme3.renderer.Camera;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Node;
import com.jme3.system.AppSettings;
import cz.ascaria.zoneofuprising.Main;
import cz.ascaria.zoneofuprising.ZoneOfUprising;
import java.util.concurrent.ScheduledThreadPoolExecutor;

/**
 * Base class for all app states.
 * @author Ascaria
 */
abstract public class BaseAppState extends AbstractAppState
{
    protected AppStateManager stateManager;
    protected ZoneOfUprising app;

    protected AppSettings settings;
    protected ScheduledThreadPoolExecutor executor;

    protected InputManager inputManager;
    protected AssetManager assetManager;

    protected Node rootNode;
    protected Node guiNode;

    protected ViewPort viewPort;
    protected ViewPort guiViewPort;

    protected Camera cam;

    @Override
    public void initialize(AppStateManager stateManager, Application app)
    {
        super.initialize(stateManager, app);

        this.stateManager = stateManager;
        this.app = (ZoneOfUprising)app;

        viewPort = app.getViewPort();
        guiViewPort = app.getGuiViewPort();
        settings = app.getContext().getSettings();
        executor = Main.executor;//((ZoneOfUprising)app).getExecutor();
        inputManager = app.getInputManager();
        assetManager = app.getAssetManager();
        rootNode = ((ZoneOfUprising)app).getRootNode();
        guiNode = ((ZoneOfUprising)app).getGuiNode();
        cam = app.getCamera();
        // You must set initialized true in descendants as last as possible
    }

    @Override
    public void cleanup()
    {
        super.cleanup();
    }
}
