/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.world;

import com.jme3.app.Application;
import com.jme3.app.state.AppStateManager;
import com.jme3.network.Filters;
import com.jme3.network.HostedConnection;
import com.jme3.network.Message;
import com.jme3.network.MessageListener;
import com.jme3.network.Server;
import com.jme3.scene.Node;
import cz.ascaria.network.messages.LoadingMessage;
import cz.ascaria.network.messages.UnloadingMessage;
import cz.ascaria.network.messages.WorldLoadedMessage;
import cz.ascaria.network.server.Console;
import cz.ascaria.network.sync.ServerSyncManager;
import cz.ascaria.zoneofuprising.entities.ShipBuilder;
import java.util.concurrent.Callable;

/**
 *
 * @author Ascaria Quynn
 */
public class ServerWorldManager extends BaseWorldManager implements MessageListener<HostedConnection> {

    private String defaultShip = "dark_fighter_6";

    private Server server;

    public ServerWorldManager(Server server, String worldPath) {
        super(worldPath);
        this.server = server;
    }

    @Override
    public void initialize(AppStateManager stateManager, Application app) {
        super.initialize(stateManager, app);

        server.addMessageListener(this,
            WorldLoadedMessage.class
        );

        syncManager = new ServerSyncManager(server);
        stateManager.attach(syncManager);
    }

    @Override
    public void cleanup() {

        stateManager.detach(syncManager);
        syncManager = null;

        super.cleanup();
    }

    @Override
    public void worldLoaded(Node world) {
        super.worldLoaded(world);
        Console.sysprintln("World '" + worldPath + "' is loaded");
    }

    @Override
    public void worldUnloaded(Node world) {
        super.worldUnloaded(world);
        Console.sysprintln("World is unloaded");
    }

    @Override
    public void entityLoaded(String entityName, Node entity) {
        // Add synchronization to entity
        syncManager.addEntity(entityName, entity);
        Console.sysprintln("Entity '" + entityName + "' ('" + entity + "') loaded");
    }

    @Override
    public void entityUnloaded(String entityName, Node entity) {
        // Remove synchronization from entity
        syncManager.removeEntity(entityName);
        Console.sysprintln("Entity '" + entityName + "' ('" + entity + "') unloaded");
    }

    /**
     * Load client.
     * @param client 
     */
    public void loadClient(HostedConnection client) {
        // Tell new client what world to load
        Console.sysprintln("Server telling Client " + client.getId() + " to load world '" + this.worldPath + "'");
        client.send(new LoadingMessage().add(new String[] {"world", this.worldPath}));
    }

    /**
     * Unload client.
     * @param client 
     */
    public void unloadClient(final HostedConnection client) {
        String playerName = client.getAttribute("name");
        if(entityExists(playerName)) {
            // Unload client's entity on server
            unloadEntity(playerName);
            // Tell other clients what to unload
            Console.sysprintln("Server telling Clients (except Client '" + playerName + "') to unload Client '" + playerName + "'");
            server.broadcast(Filters.notIn(client), new UnloadingMessage().add(new String[] {"entity", playerName}));
        } else {
            Console.sysprintln("Trying to unload client " + client.getId() + ", but player does not exist.");
        }
    }

    public void messageReceived(final HostedConnection source, final Message m) {
        app.enqueue(new Callable() {
            public Object call() throws Exception {
                if(m instanceof WorldLoadedMessage) {
                    worldLoadedMessage(source, (WorldLoadedMessage)m);
                }
                return null; 
            } 
        }); 
    }

    /**
     * Called when new client tells to server that he loaded the world.
     * @param client
     * @param m 
     */
    public void worldLoadedMessage(HostedConnection client, WorldLoadedMessage m) {
        Console.sysprintln("Client " + client.getId() + " announced that he loaded the world '" + m.worldPath + "'");

        if(!m.worldPath.equals(worldPath)) {
            Console.sysprintln("Client " + client.getId() + " loaded bad world, on server is loaded world '" + worldPath + "', kicking...");
            client.close("You have loaded bad world '" + m.worldPath + "', on server is loaded world '" + worldPath + "'");
        }

        // Get new player's name
        String playerName = client.getAttribute("name");

        // Must be called first. Tells new client what entities to load (here new client loads only other entities)
        Console.sysprintln("Server telling Client " + client.getId() + " to load other entities");
        LoadingMessage loadingMessage = new LoadingMessage();
        for(String entityName : entities.keySet()) {
            loadingMessage.add(new String[] {"entity", entityName, defaultShip});
        }
        client.send(loadingMessage);

        // Must be called second. Load client's entity on server, so that next broadcast will tell new client what is his own entity
        Console.sysprintln("Loading entity on server " + defaultShip + " (Client " + client.getId() + " " + playerName + ")");
        loadEntity((String)client.getAttribute("name"), defaultShip, ShipBuilder.class);

        // Must be called third. Tell all clients (including new client) what entity to load, so new client loads his own entity here
        Console.sysprintln("Server telling all Clients (including new client) to load " + defaultShip + " for client " + playerName);
        server.broadcast(new LoadingMessage().add(new String[] {"entity", playerName, defaultShip}));
    }
}
