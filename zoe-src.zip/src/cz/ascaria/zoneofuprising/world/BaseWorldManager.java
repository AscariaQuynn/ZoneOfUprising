/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.world;

import com.jme3.app.Application;
import com.jme3.app.state.AppStateManager;
import com.jme3.asset.AssetManager;
import com.jme3.bullet.BulletAppState;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.bullet.objects.PhysicsRigidBody;
import com.jme3.input.InputManager;
import com.jme3.light.AmbientLight;
import com.jme3.light.DirectionalLight;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.post.FilterPostProcessor;
import com.jme3.post.filters.BloomFilter;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.Node;
import com.jme3.scene.SceneGraphVisitor;
import com.jme3.scene.Spatial;
import com.jme3.shadow.DirectionalLightShadowRenderer;
import cz.ascaria.network.server.Console;
import cz.ascaria.network.sync.BaseSyncManager;
import cz.ascaria.zoneofuprising.ZoneOfUprising;
import cz.ascaria.zoneofuprising.appstates.LoadingAppState;
import cz.ascaria.zoneofuprising.appstates.UnloadingAppState;
import cz.ascaria.zoneofuprising.controls.LightsControl;
import cz.ascaria.zoneofuprising.entities.EntityBuilder;
import cz.ascaria.zoneofuprising.input.PhysicsInputListener;
import cz.ascaria.zoneofuprising.entities.PlayerVisitor;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * @author Ascaria Quynn
 */
abstract public class BaseWorldManager extends BulletAppState
{
    public String worldPath;

    final public Map<String, Node> nodes = new HashMap<String, Node>();
    final public Map<String, Node> entities = new HashMap<String, Node>();
    final public List<Spatial> targetables = new LinkedList<Spatial>();

    protected ViewPort viewPort;

    protected Node rootNode;

    protected AssetManager assetManager;
    protected InputManager inputManager;

    protected BaseSyncManager syncManager;

    protected AmbientLight ambientLight;
    protected DirectionalLight sun;
    final protected static int SHADOWMAP_SIZE = 1024;
    final protected static int NB_SPLITS = 4;
    protected FilterPostProcessor fpp;
    protected DirectionalLightShadowRenderer dlsr;

    private PhysicsInputListener listener;

    public BaseWorldManager(String worldPath) {
        this.worldPath = worldPath;
    }

    @Override
    public void initialize(AppStateManager stateManager, Application app)
    {
        super.initialize(stateManager, app);
        initialized = true;
        getPhysicsSpace().setGravity(Vector3f.ZERO);

        viewPort = app.getViewPort();

        rootNode = ((ZoneOfUprising)app).getRootNode();

        assetManager = app.getAssetManager();
        inputManager = app.getInputManager();

        for(String nodeName : new String[] {"worldNode", "entitiesNode"}) {
            Node node = new Node(nodeName);
            nodes.put(nodeName, node);
            rootNode.attachChild(node);
        }

        // Add lights
        rootNode.addLight(ambientLight = new AmbientLight() {{
            setColor(ColorRGBA.White.mult(0.7f));
        }});
        rootNode.addLight(sun = new DirectionalLight() {{
            setColor(ColorRGBA.White.mult(1.3f));
            setDirection(new Vector3f(0.5f, -0.5f, 0.5f).normalizeLocal());
        }});
        // Add shadows
        viewPort.addProcessor(fpp = new FilterPostProcessor(assetManager) {{
            //addFilter(new SSAOFilter(12.94f, 43.92f, 0.33f, 0.61f));
            addFilter(new BloomFilter(BloomFilter.GlowMode.Objects) {{
                setDownSamplingFactor(2.0f); 
                setBloomIntensity(2f);
                setBlurScale(1.5f);
            }});
            /*addFilter(new DirectionalLightShadowFilter(assetManager, BaseWorldManager.SHADOWMAP_SIZE, BaseWorldManager.NB_SPLITS) {{
                setLight(BaseWorldManager.this.sun);
                setEnabled(true);
            }});*/
        }});
        /*viewPort.addProcessor(dlsr = new DirectionalLightShadowRenderer(assetManager, BaseWorldManager.SHADOWMAP_SIZE, BaseWorldManager.NB_SPLITS) {{
            setLight(BaseWorldManager.this.sun);
        }});*/

        // Initialize Run/Pause independent stuff
        listener = new PhysicsInputListener(inputManager);
        listener.baseWorldManager = this;
        listener.registerInputs();

        Console.sysprintln("World Manager initialized, loading world...");
        loadWorld(worldPath);
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        listener.enabled = enabled;
    }

    @Override
    public void cleanup()
    {
        initialized = false;

        if(isWorldLoaded()) {
            unloadWorld();
        }

        listener.clearInputs();
        listener = null;

        // Remove shadows
        viewPort.removeProcessor(fpp);
        fpp = null;
        /*viewPort.removeProcessor(dlsr);
        dlsr = null;*/
        // Remove lights
        rootNode.removeLight(ambientLight);
        ambientLight = null;
        rootNode.removeLight(sun);
        sun = null;

        super.cleanup();
    }

    public boolean isWorldLoaded() {
        return nodes.containsKey("worldNode") && nodes.get("worldNode").getQuantity() > 0;
    }

    /**
     * Loads given world.
     * @param worldPath 
     */
    public void loadWorld(final String worldPath) {
        if(isWorldLoaded()) {
            throw new IllegalStateException("World is already loaded.");
        }
        this.worldPath = worldPath;
        stateManager.attach(new LoadingAppState() {
            @Override
            protected Node onLoadModel() {
                return (Node)assetManager.loadModel(worldPath);
            }
            @Override
            protected void onLoadingComplete(Node model) {
                nodes.get("worldNode").attachChild(model);
                getPhysicsSpace().addAll(model);
                worldLoaded(model);
            }
        });
    }

    public void unloadWorld() {
        if(!isWorldLoaded()) {
            throw new IllegalStateException("World is not loaded.");
        }
        this.worldPath = null;
        stateManager.attach(new UnloadingAppState() {
            @Override
            protected void onUnloadModel() {
                if(isWorldLoaded()) {
                    // Get world
                    Node world = (Node)nodes.get("worldNode").getChild(0);
                    // Remove world
                    nodes.get("worldNode").detachChild(world);
                    getPhysicsSpace().removeAll(world);
                    worldUnloaded(world);
                }
            }
        });
        for(String entityName : entities.keySet()) {
            unloadEntity(entityName);
        }
    }

    /**
     * Implement what to do after world is loaded.
     * @param world
     */
    public void worldLoaded(Node world) {
        world.depthFirstTraversal(new SceneGraphVisitor() {
            public void visit(Spatial spatial) {
                syncManager.addEntity(spatial);
            }
        });
    }

    /**
     * Implement what to do after world is ulloaded.
     * @param world
     */
    public void worldUnloaded(Node world) {
        world.depthFirstTraversal(new SceneGraphVisitor() {
            public void visit(Spatial spatial) {
                syncManager.removeEntity((String)spatial.getUserData("entityName"));
            }
        });
    }

    /**
     * Do entity exist?
     * @param name
     * @return 
     */
    public boolean entityExists(String name) {
        return entities.containsKey(name);
    }

    /**
     * Loads npc entity.
     * @param entityName
     * @param entityBuilder
     */
    public void loadEntity(final String entityName, final String entityPath, final Class<?extends EntityBuilder> entityBuilder) {
        stateManager.attach(new LoadingAppState() {
            @Override
            protected Node onLoadModel() throws Exception {
                // Construct entity and return loaded model
                EntityBuilder instance = entityBuilder.newInstance();
                instance.initialize(assetManager, entityPath);
                return instance.buildEntity();
            }
            @Override
            protected void onLoadingComplete(Node model) {
                // Add entity to world
                nodes.get("entitiesNode").attachChild(model);
                getPhysicsSpace().addAll(model);
                // Find entity position
                PlayerVisitor playerVisitor = new PlayerVisitor();
                nodes.get("worldNode").depthFirstTraversal(playerVisitor);
                // Update entity control with player position
                PhysicsRigidBody rigidBody = model.getControl(RigidBodyControl.class);
                rigidBody.setPhysicsLocation(playerVisitor.player.getWorldTranslation().clone());
                rigidBody.setPhysicsRotation(playerVisitor.player.getWorldRotation().clone());
                // Add entity to list
                entities.put(entityName, model);
                targetables.add(model);
                // Add lights that entity have
                LightsControl lightsControl = model.getControl(LightsControl.class);
                if(null != lightsControl) {
                    lightsControl.setLightsNode(rootNode);
                }
                // Entity is fully loaded
                entityLoaded(entityName, model);
            }
        });
    }

    /**
     * Unloads given entity.
     * @param entityName 
     */
    public void unloadEntity(final String entityName) {
        stateManager.attach(new UnloadingAppState() {
            @Override
            protected void onUnloadModel() {
                // Get entity
                Node entity = entities.get(entityName);
                if(null != entity) {
                    // Remove entity from world
                    nodes.get("entitiesNode").detachChild(entity);
                    getPhysicsSpace().removeAll(entity);
                    // Remove entity
                    entities.remove(entityName);
                    entityUnloaded(entityName, entity);
                }
            }
        });
    }

    /**
     * Implement what to do after entity is loaded.
     * @param entityName
     * @param entity
     */
    abstract public void entityLoaded(String entityName, Node entity);

    /**
     * Implement what to do after entity is unloaded.
     * @param entityName
     * @param entity
     */
    abstract public void entityUnloaded(String entityName, Node entity);
}
