/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.world;

import com.jme3.app.Application;
import com.jme3.app.state.AppStateManager;
import com.jme3.cursors.plugins.JmeCursor;
import com.jme3.effect.ParticleEmitter;
import com.jme3.network.Client;
import com.jme3.renderer.Camera;
import com.jme3.scene.Node;
import cz.ascaria.network.messages.WorldLoadedMessage;
import cz.ascaria.network.sync.ClientSyncManager;
import cz.ascaria.zoneofuprising.controls.AlignByVelocityControl;
import cz.ascaria.zoneofuprising.controls.UserInputControl;
import cz.ascaria.zoneofuprising.gui.GuiManager;
import cz.ascaria.zoneofuprising.gui.HudLayout;
import cz.ascaria.zoneofuprising.input.WorldInputListener;
import cz.ascaria.zoneofuprising.entities.CamerasVisitor;
import cz.ascaria.zoneofuprising.entities.EntityBuilder;
import cz.ascaria.zoneofuprising.entities.ParticleBuilder;

/**
 *
 * @author Ascaria Quynn
 */
public class ClientWorldManager extends BaseWorldManager {

    private String playerName;
    private Client client;
    private GuiManager guiManager;

    private WorldInputListener worldInputListener;

    private Camera cam;



    public ClientWorldManager(Client client, GuiManager guiManager, String worldPath, String playerName) {
        super(worldPath);
        this.client = client;
        this.guiManager = guiManager;
        this.playerName = playerName;
    }

    @Override
    public void initialize(AppStateManager stateManager, Application app) {
        super.initialize(stateManager, app);
        cam = app.getCamera();

        worldInputListener = new WorldInputListener(inputManager);
        worldInputListener.guiManager = guiManager;
        worldInputListener.registerInputs();

        syncManager = new ClientSyncManager(client);
        stateManager.attach(syncManager);

        // Tell server that we successfully loaded the world.
        client.send(new WorldLoadedMessage(worldPath));
    }

    @Override
    public void cleanup() {

        stateManager.detach(syncManager);
        syncManager = null;

        worldInputListener.clearInputs();
        worldInputListener = null;

        client = null;

        cam = null;

        super.cleanup();
    }

    @Override
    public void worldLoaded(Node world) {
        super.worldLoaded(world);
        guiManager.show(HudLayout.class);
    }

    @Override
    public void worldUnloaded(Node world) {
        super.worldUnloaded(world);
    }

    @Override
    public void loadEntity(String entityName, String entityPath, Class<?extends EntityBuilder> entityBuilder) {
        super.loadEntity(entityName, entityPath, entityBuilder);
        System.out.println("Entity '" + entityName + "' loaded on client '" + playerName + "'.");
    }

    @Override
    public void unloadEntity(String entityName) {
        super.unloadEntity(entityName);
        System.out.println("Entity '" + entityName + "' unloaded on client '" + playerName + "'.");
    }

    @Override
    public void entityLoaded(String entityName, Node entity) {
        // Add synchronization to entity
        syncManager.addEntity(entityName, entity);
        // If loaded entity is my entity
        if(playerName.equals(entityName)) {
            // Debris around player's entity 
            ParticleBuilder particleBuilder = new ParticleBuilder(assetManager);
            particleBuilder.buildDebris(entity);
            // Add camera to entity
            CamerasVisitor camerasVisitor = new CamerasVisitor(cam);
            entity.depthFirstTraversal(camerasVisitor);
            // Add user control to entity
            UserInputControl userInputControl = new UserInputControl(client, entityName, inputManager);
            userInputControl.gunSight = (JmeCursor)assetManager.loadAsset("Interface/GunSights/DefaultTurretSight.ico");
            userInputControl.mouseSensivity = 2.5f;
            userInputControl.setMouseControlEnabled(true);
            userInputControl.registerInputs();
            entity.addControl(userInputControl);
            worldInputListener.userInputControl = userInputControl;
            // Add user input control to hud layout
            HudLayout hudLayout = (HudLayout)guiManager.getLayout(HudLayout.class);
            hudLayout.userControl = userInputControl;
        }
    }

    @Override
    public void entityUnloaded(String entityName, Node entity) {
        // Remove synchronization from ship
        syncManager.removeEntity(entityName);
        // If unloaded ship is player's ship
        if(playerName.equals(entityName)) {
            UserInputControl userInputControl = entity.getControl(UserInputControl.class);
            if(null != userInputControl) {
                userInputControl.clearInputs();
                worldInputListener.userInputControl = null;
                entity.removeControl(userInputControl);
            }
        }
    }
}
