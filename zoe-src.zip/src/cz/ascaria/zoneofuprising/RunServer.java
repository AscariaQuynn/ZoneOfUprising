/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising;

/**
 *
 * @author Ascaria Quynn
 */
public class RunServer {
    public static void main(String[] args) {
        Main.main(new String[] { "-server", "-withhead" });
    }
}
