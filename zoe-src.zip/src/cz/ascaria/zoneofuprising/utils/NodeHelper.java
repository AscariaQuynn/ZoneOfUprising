/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.utils;

import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.math.Vector3f;
import com.jme3.scene.Spatial;

/**
 *
 * @author Ascaria Quynn
 */
public class NodeHelper {
    /**
     * Returns simulated "local translation" between two spatials.
     * @param ancestor simulated or real ancestor
     * @param child simulated or real child
     * @return 
     */
    public static Vector3f getLocalTranslation(Spatial ancestor, Spatial child) {
        return child.getWorldTranslation().subtract(ancestor.getWorldTranslation());
    }

    /**
     * Returns simulated "local translation" between two vectors.
     * @param ancestor simulated or real "ancestor"
     * @param child simulated or real "child"
     * @return 
     */
    public static Vector3f getLocalTranslation(Vector3f ancestor, Vector3f child) {
        return child.subtract(ancestor);
    }

    /**
     * Tries to find rigid body control.
     * @param spatial
     * @param iterations
     * @return 
     */
    public static RigidBodyControl tryFindRigidBody(Spatial child, int iterations) {
        RigidBodyControl rb = null;
        for(int i = 0; i < 3; i++) {
            rb = child.getControl(RigidBodyControl.class);
            if(null != rb) {
                break;
            }
            child = child.getParent();
        }
        return rb;
    }
}
