/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.utils;

import com.jme3.math.Vector3f;

/**
 *
 * @author Ascaria Quynn
 */
public class Strings {
    
    /**
     * Rounds Vector3f to specified decimal places (including zeros) an returns as string representation.
     * @param vector
     * @param decimalPlaces
     * @return 
     */
    public static String roundVector(Vector3f vector, int decimalPlaces) {
        return "(" + (vector.x >= 0f ? "+" : "-") + String.format("%." + decimalPlaces + "f", Math.abs(vector.x))
            + ", " + (vector.y >= 0f ? "+" : "-") + String.format("%." + decimalPlaces + "f", Math.abs(vector.y))
            + ", " + (vector.z >= 0f ? "+" : "-") + String.format("%." + decimalPlaces + "f", Math.abs(vector.z))
        + ")";
    }

    public static boolean isEmpty(String str) {
        return null == str || str.isEmpty();
    }
}
