/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.utils;

import com.jme3.system.AppSettings;
import cz.ascaria.zoneofuprising.Main;
import java.util.logging.Level;
import java.util.prefs.BackingStoreException;

/**
 *
 * @author Ascaria
 */
public class SettingsLoader
{
    /**
     * Creates standard AppSettings and fills it with custom, game related stuff
     * @return 
     */
    public AppSettings load()
    {
        // Instantiate standard settings
        AppSettings settings = new AppSettings(true);
        settings.setResolution(1280, 720);
        settings.setFrameRate(60);
        settings.setVSync(true);
        settings.setTitle("Zone of Uprising");
        // Try load window icon
        loadIcon(settings);
        // Try load saved settings
        loadSavedSettings(settings);
        // Return fully prepared settings
        return settings;
    }

    private void loadIcon(AppSettings settings)
    {
        /*try {
            settings.setIcons(new BufferedImage[] {
                ImageIO.read(new File("assets/Interface/Backgrounds/icon.jpg"))
            });
        } catch(Exception e) {
        }*/
    }

    private void loadSavedSettings(AppSettings settings)
    {
        try {
            // Try load saved settings
            settings.load("cz.ascaria.zoneofuprising");
        } catch(BackingStoreException ex) {
            Main.LOG.log(Level.SEVERE, "Load settings failed", ex);
        }
    }
}
