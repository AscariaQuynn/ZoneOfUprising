/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.utils;

import com.jme3.math.Vector3f;

/**
 *
 * @author Ascaria Quynn
 */
public class Vector3fHelper {
    /**
     * Locally subtract or add 1f from all directions towards 0f.
     * @param v 
     */
    public static void goTowardsZero(Vector3f v) {
        if(v.x != 0f) {
            v.x = Math.round(v.x > 0f ? v.x - 1f : v.x + 1f);
        }
        if(v.y != 0f) {
            v.y = Math.round(v.y > 0f ? v.y - 1f : v.y + 1f);
        }
        if(v.z != 0f) {
            v.z = Math.round(v.z > 0f ? v.z - 1f : v.z + 1f);
        }
    }
}
