/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.controls;

import com.jme3.audio.AudioNode;
import com.jme3.audio.AudioSource.Status;
import com.jme3.bullet.collision.shapes.CollisionShape;
import com.jme3.effect.ParticleEmitter;
import com.jme3.math.Vector3f;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import cz.ascaria.zoneofuprising.utils.Vector3fHelper;
import java.util.ArrayList;

/**
 *
 * @author Ascaria Quynn
 */
public class SpaceShipControl extends PhysicsSpaceShip {

    public AudioNode engineSound;

    protected ParticleEmitter engineEmitter;
    protected float particlesPerSec = 0f;

    protected Vector3f isAccelerating = new Vector3f();

    protected int gunMode = 1;

    protected ArrayList<Node> turretSlots = new ArrayList<Node>();
    protected ArrayList<TurretControl> turretControls = new ArrayList<TurretControl>();

    protected ArrayList<Node> fixedGunSlots = new ArrayList<Node>();
    protected ArrayList<FixedGunControl> fixedGunControls = new ArrayList<FixedGunControl>();

    /**
     * @param shape
     */
    public SpaceShipControl(CollisionShape shape) {
        super(shape);
    }

    /**
     * @param shape
     * @param mass 
     */
    public SpaceShipControl(CollisionShape shape, float mass) {
        super(shape, mass);
    }

    /**
     * Sets engine particle emitter.
     * @param engineEmitter 
     */
    public void setEngineEmitter(ParticleEmitter engineEmitter) {
        this.engineEmitter = engineEmitter;
        particlesPerSec = engineEmitter.getParticlesPerSec();
    }

    /**
     * Adds turret slot.
     * @param node 
     */
    public void addTurretSlot(Node node) {
        turretSlots.add(node);
    }

    /**
     * Adds fixed slot.
     * @param node 
     */
    public void addFixedGunSlot(Node node) {
        fixedGunSlots.add(node);
    }

    /**
     * Adds turret at the next ship turret position.
     * @param turret
     * @return true if turret was added, false otherwise
     */
    public boolean addTurret(Node turret) {
        if(turretSlots.size() > 0) {
            for(Node turretSlot : turretSlots) {
                if(turretSlot.getQuantity() == 0) {
                    TurretControl turretControl = turret.getControl(TurretControl.class);
                    if(null != turretControl && null != spatial) {
                        // Set Parent Node and Control for getting location, velocity and rotation
                        turretControl.setParent((Node)spatial, this);
                        // Add turret
                        turretSlot.attachChild(turret);
                        turretControls.add(turretControl);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Adds fixed gun at the next ship fixed slot position.
     * @param fixedGun
     * @return true if fixed gun was added, false otherwise
     */
    public boolean addFixedGun(Node fixedGun) {
        if(fixedGunSlots.size() > 0) {
            for(Node fixedGunSlot : fixedGunSlots) {
                if(fixedGunSlot.getQuantity() == 0) {
                    FixedGunControl fixedGunControl = fixedGun.getControl(FixedGunControl.class);
                    if(null != fixedGunControl) {
                        // Add fixed gun
                        fixedGunSlot.attachChild(fixedGun);
                        fixedGunControls.add(fixedGunControl);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Returns number of projectiles in the ship.
     * @return 
     */

    public int getRemainingProjectilesCount() {
        int count = 0;
        for(TurretControl turretControl : turretControls) {
            count += turretControl.getRemainingProjectilesCount();
        }
        for(FixedGunControl fixedGunControl : fixedGunControls) {
            count += fixedGunControl.getRemainingProjectilesCount();
        }
        return count;
    }

    @Override
    public void update(float tpf) {
        super.update(tpf);
        // Main engine emitter
        if(null != engineEmitter) {
            if(isAccelerating(Vector3f.UNIT_Z) && engineEmitter.getParticlesPerSec() == 0f) {
                engineEmitter.setParticlesPerSec(particlesPerSec);
            } else if(!isAccelerating(Vector3f.UNIT_Z) && engineEmitter.getParticlesPerSec() > 0f) {
                engineEmitter.setParticlesPerSec(0f);
            }
        }
        // Reduce acceleration amount
        if(!isAccelerating.equals(Vector3f.ZERO)) {
            Vector3fHelper.goTowardsZero(isAccelerating);
        }
        // Play engine sound
        if(null != engineSound) {
            // If we accelerating and not playing sound
            if(isAccelerating(Vector3f.UNIT_Z) && !engineSound.getStatus().equals(Status.Playing)) {
                engineSound.play();
            }
            // If we do not accelerating and playing sound
            if(!isAccelerating(Vector3f.UNIT_Z) && engineSound.getStatus().equals(Status.Playing)) {
                engineSound.stop();
            }
        }
    }

    /**
     * Apply yaw torque to the left (positive value) or to the right (negative value)
     * @param value 
     */
    public void yaw(float value) {
        if(rotation.y == 0f) {
            rotation.y = value;
        }
    }

    /**
     * Apply pitch torque to the up (negative value) or down (positive value)
     * @param value 
     */
    public void pitch(float value) {
        if(rotation.x == 0f) {
            rotation.x = value;
        }
    }

    /**
     * Apply roll torque to the left (negative value) or to the right (positive value)
     * @param value 
     */
    public void roll(float value) {
        if(rotation.z == 0f) {
            rotation.z = value;
        }
    }

    /**
     * Apply ascending (positive value) or descending (negative value) force.
     * @param value Value of the axis, from 0f to 1f.
     */
    public void ascent(float value) {
        if(acceleration.y == 0f) {
            acceleration.y = value;
        }
        if(value != 0f) {
            isAccelerating.y = value >= 0f ? 10f : -10f;
        }
    }

    /**
     * Apply accelerating (positive value) or reversing (negative value) force.
     * @param value Value of the axis, from 0f to 1f.
     */
    public void accelerate(float value) {
        if(acceleration.z == 0f) {
            acceleration.z = value;
        }
        if(value != 0f) {
            isAccelerating.z = value >= 0f ? 10f : -10f;
        }
    }

    /**
     * Apply strafing force to the left (positive value) or right (negative value) side.
     * @param value Value of the axis, from 0f to 1f.
     */
    public void strafe(float value) {
        if(acceleration.x == 0f) {
            acceleration.x = value;
        }
        if(value != 0f) {
            isAccelerating.x = value >= 0f ? 10f : -10f;
        }
    }

    /**
     * Set if ship is accelerating.
     * @param isAccelerating
     */
    public void setIsAccelerating(Vector3f isAccelerating) {
        this.isAccelerating = isAccelerating;
    }

    /**
     * Get if ship is accelerating.
     * @return
     */
    public Vector3f getIsAccelerating() {
        return isAccelerating;
    }

    /**
     * Is ship accelerating in one particular direction?
     * @param direction y = 1 ascent, y = -1 descent, z = 1 forward, z = -1 backward, x = 1 strafe left, x = -1 strafe right
     */
    public boolean isAccelerating(Vector3f direction) {
        // Do we accelerate in particular direction?
        if((direction.y > 0f && isAccelerating.y > 0f)
            || (direction.y < 0f && isAccelerating.y < 0f)
            || (direction.z > 0f && isAccelerating.z > 0f)
            || (direction.z < 0f && isAccelerating.z < 0f)
            || (direction.x > 0f && isAccelerating.x > 0f)
            || (direction.x < 0f && isAccelerating.x < 0f)) {
            return true;
        }
        return false;
    }

    /**
     * Toggle ship gun mode.
     * @param gunMode 
     */
    public void setGunMode(int gunMode) {
        this.gunMode = gunMode;
    }

    /**
     * Locks target to the specified collision results.
     * @param results 
     */
    public void lockTarget(Geometry target) {
        for(TurretControl turretControl : turretControls) {
            turretControl.lockTarget(target);
        }
    }

    /**
     * Returns true if all guns are locked to the target simultaneously, false otherwise.
     * @return 
     */
    public boolean isTargetLocked() {
        for(TurretControl turretControl : turretControls) {
            if(!turretControl.isTargetLocked()) {
                return false;
            }
        }
        return true;
    }

    /**
     * Returns true if all guns are in cooldown simultaneously, false otherwise.
     * @return 
     */
    public boolean isCooldown() {
        for(TurretControl turretControl : turretControls) {
            if(turretControl.isCooldown()) {
                return true;
            }
        }
        return false;
    }

    /**
     * I wanna kill some toasters!
     */
    public void fire() {
        if(gunMode == 1 || gunMode == 2) {
            for(TurretControl turretControl : turretControls) {
                turretControl.fire();
            }
        }
        if(gunMode == 1 || gunMode == 3) {
            for(FixedGunControl fixedGunControl : fixedGunControls) {
                fixedGunControl.fire();
            }
        }
    }

    public void cease() {
        for(TurretControl turretControl : turretControls) {
            turretControl.cease();
        }
        for(FixedGunControl fixedGunControl : fixedGunControls) {
            fixedGunControl.cease();
        }
    }

    public void switchSpotLights(boolean enable) {
        LightsControl lightsControl = spatial.getControl(LightsControl.class);
        if(null != lightsControl) {
            lightsControl.switchSpotLights(enable);
        }
    }

    public void switchPointLights(boolean enable) {
        LightsControl lightsControl = spatial.getControl(LightsControl.class);
        if(null != lightsControl) {
            lightsControl.switchPointLights(enable);
        }
    }
}
