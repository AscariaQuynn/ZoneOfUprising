/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.controls;

import com.jme3.light.Light;
import com.jme3.light.PointLight;
import com.jme3.light.SpotLight;
import com.jme3.scene.Node;
import java.util.LinkedList;

/**
 *
 * @author Ascaria Quynn
 */
public class LightsControl extends ControlAdapter {

    protected Node lightsNode;
    protected LinkedList<Light> spotLights = new LinkedList<Light>();
    protected LinkedList<Light> pointLights = new LinkedList<Light>();

    public boolean isEmpty() {
        return spotLights.isEmpty() && pointLights.isEmpty();
    }

    /**
     * Set node to lights add to.
     * @param lightsNode 
     */
    public void setLightsNode(Node lightsNode) {
        this.lightsNode = lightsNode;
    }

    /**
     * Turns spot lights on or off.
     * @param enable true on, false off
     */
    public void switchSpotLights(boolean enable) {
        if(null == lightsNode) {
            throw new IllegalStateException("You must use SpaceShipControl.setLightsNode() first.");
        }
        for(Light light : spotLights) {
            if(enable) {
                lightsNode.addLight(light);
            } else {
                lightsNode.removeLight(light);
            }
        }
    }

    /**
     * Turns point lights on or off.
     * @param enable true on, false off
     */
    public void switchPointLights(boolean enable) {
        if(null == lightsNode) {
            throw new IllegalStateException("You must use SpaceShipControl.setLightsNode() first.");
        }
        for(Light light : pointLights) {
            if(enable) {
                lightsNode.addLight(light);
            } else {
                lightsNode.removeLight(light);
            }
        }
    }

    /**
     * Adds light.
     * @param light 
     */
    public void addLight(Light light) throws IllegalArgumentException {
        if(light instanceof SpotLight) {
            spotLights.add(light);
        } else if(light instanceof PointLight) {
            pointLights.add(light);
        } else {
            throw new IllegalArgumentException("Light of type '" + light.getType() + "' is not supported.");
        }
    }
}
