/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.controls;

import com.jme3.cursors.plugins.JmeCursor;
import com.jme3.input.InputManager;
import com.jme3.input.KeyInput;
import com.jme3.input.MouseInput;
import com.jme3.input.controls.ActionListener;
import com.jme3.input.controls.AnalogListener;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.input.controls.MouseAxisTrigger;
import com.jme3.input.controls.MouseButtonTrigger;
import com.jme3.input.controls.Trigger;
import com.jme3.network.Client;
import com.jme3.scene.Spatial;
import cz.ascaria.network.messages.ShipActionMessage;
import cz.ascaria.network.messages.ShipAnalogMessage;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Ascaria Quynn
 */
public class UserInputControl extends ControlAdapter implements ActionListener, AnalogListener {

    protected InputManager inputManager;

    public float mouseSensivity = 1f;
    protected boolean mouseControlEnabled = false;
    protected boolean mouseRolling = false;

    public JmeCursor gunSight;
    protected Client client;
    protected String playerName;
    protected SpaceShipControl spaceShipControl;

    protected HashMap<String, Trigger[]> triggers = new HashMap<String, Trigger[]>() {{
        put("ShipMoveUp", new Trigger[] { new KeyTrigger(KeyInput.KEY_Q) });
        put("ShipMoveDown", new Trigger[] { new KeyTrigger(KeyInput.KEY_E) });
        put("ShipMoveLeft", new Trigger[] { new KeyTrigger(KeyInput.KEY_A) });
        put("ShipMoveRight", new Trigger[] { new KeyTrigger(KeyInput.KEY_D) });
        put("ShipMoveForward", new Trigger[] { new KeyTrigger(KeyInput.KEY_W) });
        put("ShipMoveBackward", new Trigger[] { new KeyTrigger(KeyInput.KEY_S) });

        put("ShipYawLeft", new Trigger[] { new KeyTrigger(KeyInput.KEY_U) });
        put("ShipYawRight", new Trigger[] { new KeyTrigger(KeyInput.KEY_O) });
        put("ShipPitchUp", new Trigger[] { new KeyTrigger(KeyInput.KEY_K) });
        put("ShipPitchDown", new Trigger[] { new KeyTrigger(KeyInput.KEY_I) });
        put("ShipRollLeft", new Trigger[] { new KeyTrigger(KeyInput.KEY_J) });
        put("ShipRollRight", new Trigger[] { new KeyTrigger(KeyInput.KEY_L) });

        put("ShipYawRollLeftMouse", new Trigger[] { new MouseAxisTrigger(MouseInput.AXIS_X, true) });
        put("ShipYawRollRightMouse", new Trigger[] { new MouseAxisTrigger(MouseInput.AXIS_X, false) });
        put("ShipPitchUpMouse", new Trigger[] { new MouseAxisTrigger(MouseInput.AXIS_Y, false) });
        put("ShipPitchDownMouse", new Trigger[] { new MouseAxisTrigger(MouseInput.AXIS_Y, true) });

        put("ShipToggleMouseControlEnabled", new Trigger[] { new KeyTrigger(KeyInput.KEY_LCONTROL) });
        put("ShipToggleMouseRolling", new Trigger[] { new MouseButtonTrigger(MouseInput.BUTTON_MIDDLE) });

        put("ShipGunModeAll", new Trigger[] {
            new KeyTrigger(KeyInput.KEY_1)
        });
        put("ShipGunModeTurrets", new Trigger[] {
            new KeyTrigger(KeyInput.KEY_2)
        });
        put("ShipGunModeFixedGuns", new Trigger[] {
            new KeyTrigger(KeyInput.KEY_3)
        });

        put("ShipLockTarget", new Trigger[] { new MouseButtonTrigger(MouseInput.BUTTON_LEFT) });
        put("ShipUnlockTarget", new Trigger[] { new MouseButtonTrigger(MouseInput.BUTTON_RIGHT) });

        put("ShipFireKey", new Trigger[] { new KeyTrigger(KeyInput.KEY_SPACE) });
        put("ShipFireMouse", new Trigger[] { new MouseButtonTrigger(MouseInput.BUTTON_LEFT) });

        put("ShipClearForces", new Trigger[] { new KeyTrigger(KeyInput.KEY_C) });

        put("ShipToggleRotationControl", new Trigger[] { new KeyTrigger(KeyInput.KEY_B) });
        put("ShipToggleMovementControl", new Trigger[] { new KeyTrigger(KeyInput.KEY_V) });
    }};

    public UserInputControl(Client client, String playerName, InputManager inputManager) {
        this.client = client;
        this.playerName = playerName;
        this.inputManager = inputManager;
    }

    @Override
    public void setSpatial(Spatial spatial) {
        super.setSpatial(spatial);
        if(null == spatial) {
            spaceShipControl = null;
            return;
        }
        spaceShipControl = spatial.getControl(SpaceShipControl.class);
        if(null == spaceShipControl) {
            throw new IllegalStateException("Cannot add UserInputControl to spatial without SpaceShipControl!");
        }
    }

    /**
     * Should mouse control the ship?
     * @param mouseControlEnabled 
     */
    public void setMouseControlEnabled(boolean mouseControlEnabled) {
        this.mouseControlEnabled = mouseControlEnabled;
        inputManager.setCursorVisible(!mouseControlEnabled);
    }

    /**
     * Is mouse control for ship enabled?
     * @return 
     */
    public boolean isMouseControlEnabled() {
        return mouseControlEnabled;
    }

    public void registerInputs() {
        System.out.println("UserInputControl registering inputs");
        for(Map.Entry<String, Trigger[]> entry : triggers.entrySet()) {
            inputManager.addMapping(entry.getKey(), entry.getValue());
        }
        inputManager.addListener(this, triggers.keySet().toArray(new String[triggers.keySet().size()]));
        // Set mouse cursor to aiming cursor
        if(null != gunSight) {
            gunSight.setxHotSpot(gunSight.getWidth() / 2);
            gunSight.setyHotSpot(gunSight.getHeight() / 2);
            inputManager.setMouseCursor(gunSight);
        }
    }

    public void clearInputs() {
        System.out.println("UserInputControl clearing inputs");
        for(String key : triggers.keySet()) {
            inputManager.deleteMapping(key);
        }
        inputManager.removeListener(this);
        // Reset mouse cursor
        inputManager.setMouseCursor(null);
        // Force cursor to be visible
        inputManager.setCursorVisible(true);
    }

    /**
     * @param name
     * @param isPressed
     * @param tpf 
     */
    public void onAction(String name, boolean isPressed, float tpf) {
        if(enabled && null != client && client.isConnected()) {
            // Create message
            ShipActionMessage m = new ShipActionMessage();
            m.setEntityName(playerName);

            if(name.equals("ShipToggleMouseControlEnabled")) {
                setMouseControlEnabled(!isPressed);
            }
            if(mouseControlEnabled && name.equals("ShipToggleMouseRolling")) {
                mouseRolling = isPressed;
            }

            if(name.equals("ToggleSpotLights")) {
                m.addAction("SwitchSpotLight", isPressed ? "On" : "Off");
            }
            if(name.equals("TogglePointLights")) {
                m.addAction("SwitchPointLight", isPressed ? "On" : "Off");
            }

            /*
            if(name.equals("ShipToggleRotationControl") && !isPressed) {
                shipControl.setRotationControl(!shipControl.isEnabledRotationControl());
            }
            if(name.equals("ShipToggleMovementControl") && !isPressed) {
                shipControl.setMovementControl(!shipControl.isEnabledMovementControl());
            }

            if(name.equals("ShipClearForces") && isPressed) {
                shipControl.setLinearVelocity(Vector3f.ZERO);
                shipControl.setAngularVelocity(Vector3f.ZERO);
            }

            if(name.equals("ShipGunModeAll") && isPressed) {
                shipControl.setGunMode(1);
            }
            if(name.equals("ShipGunModeTurrets") && isPressed) {
                shipControl.setGunMode(2);
            }
            if(name.equals("ShipGunModeFixedGuns") && isPressed) {
                shipControl.setGunMode(3);
            }

            if(name.equals("ShipLockTarget") && isPressed && !mouseControlEnabled) {
                Geometry target = null;
                if(null != target) {
                    shipControl.lockTarget(target);
                }
            }
            if(name.equals("ShipUnlockTarget") && isPressed) {
                shipControl.lockTarget(null);
            }

            if(name.equals("ShipFireKey") || (isMouseControlEnabled() && name.equals("ShipFireMouse"))) {
                // TODO: fire mode all-at-once, one-by-one, all turret's barrels at once or something like that
                if(isPressed) {
                    shipControl.fire();
                } else {
                    shipControl.cease();
                }
            }*/

            // If message is not empty
            if(!m.isEmpty()) {
                // Send message
                client.send(m);
            }
        }
    }

    /**
     * @param name
     * @param value
     * @param tpf 
     */
    public void onAnalog(String name, float value, float tpf) {
        if(enabled && null != client && client.isConnected()) {
            // Create message
            ShipAnalogMessage m = new ShipAnalogMessage();
            m.setEntityName(playerName);
            
            if(name.equals("ShipMoveUp")) {
                m.ascent = value;
            }
            if(name.equals("ShipMoveDown")) {
                m.ascent = -value;
            }
            if(name.equals("ShipMoveForward")) {
                m.accelerate = value;
            }
            if(name.equals("ShipMoveBackward")) {
                m.accelerate = -value;
            }
            if(name.equals("ShipMoveLeft")) {
                m.strafe = value;
            }
            if(name.equals("ShipMoveRight")) {
                m.strafe = -value;
            }

            if(name.equals("ShipYawLeft")) {
                m.yaw = value;
            }
            if(name.equals("ShipYawRight")) {
                m.yaw = -value;
            }
            if(name.equals("ShipRollLeft")) {
                m.roll = -value;
            }
            if(name.equals("ShipRollRight")) {
                m.roll = value;
            }
            if(name.equals("ShipPitchUp")) {
                m.pitch = -value;
            }
            if(name.equals("ShipPitchDown")) {
                m.pitch = value;
            }

            if(mouseControlEnabled) {
                if(mouseRolling) {
                    if(name.equals("ShipYawRollLeftMouse")) {
                        m.roll = Math.max(-0.02f, -value) * mouseSensivity;
                    }
                    if(name.equals("ShipYawRollRightMouse")) {
                        m.roll = Math.min(0.02f, value) * mouseSensivity;
                    }
                } else {
                    if(name.equals("ShipYawRollLeftMouse")) {
                        m.yaw = Math.min(0.02f, value) * mouseSensivity;
                    }
                    if(name.equals("ShipYawRollRightMouse")) {
                        m.yaw = Math.max(-0.02f, -value) * mouseSensivity;
                    }
                }
                if(name.equals("ShipPitchUpMouse")) {
                    m.pitch = Math.max(-0.02f, -value) * mouseSensivity;
                }
                if(name.equals("ShipPitchDownMouse")) {
                    m.pitch = Math.min(0.02f, value) * mouseSensivity;
                }
            }

            // If message is not empty
            if(!m.isEmpty()) {
                // Apply input locally and send message
                //m.applyInput(spaceShipControl);
                client.send(m);
            }
        }
    }
}
