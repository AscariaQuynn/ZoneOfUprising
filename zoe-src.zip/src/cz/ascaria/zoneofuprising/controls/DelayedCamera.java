/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.controls;

import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.renderer.Camera;
import com.jme3.scene.Spatial;

/**
 * TODO: po vypnuti flybycamera dodelat locknuti rotace i na spatial a rotovat se spatial pomoci teto kamery
 * @author Ascaria
 */
public class DelayedCamera extends ControlAdapter
{
    private Camera cam;
    private Vector3f translationOffset = new Vector3f();
    private float sensivity;

    public DelayedCamera(Camera cam) {
        this(cam, 1f);
    }

    public DelayedCamera(Camera cam, float sensivity) {
        this.cam = cam;
        this.sensivity = sensivity;
    }

    @Override
    protected void controlUpdate(float tpf)
    {
        if(enabled && null != spatial) {
            // Vytáhneme si aktuální rotaci kamery
            Quaternion cameraRotation = cam.getRotation().clone();
            // Odrotujeme ji o kousek směrem k rotaci spatialy
            //cameraRotation.slerp(spatial.getWorldRotation(), tpf * sensivity);
            cameraRotation.nlerp(spatial.getWorldRotation(), tpf * sensivity);
            // Nastavíme kameře novou rotaci
            cam.setRotation(cameraRotation);
            // Odsuneme kameru za spatialu
            cam.setLocation(spatial.getWorldTranslation().add(cameraRotation.mult(translationOffset)));
        }
    }

    /**
     * Sets the spatial for the camera control, should only be used internally.
     * @param spatial
     */
    @Override
    public void setSpatial(Spatial spatial) {
        super.setSpatial(spatial);
        if(spatial == null) {
            translationOffset.zero();
            return;
        }
        // Get positional offset from spatial's local transform and reset spatial's transform
        translationOffset = spatial.getLocalTranslation().clone();
        spatial.setLocalTranslation(Vector3f.ZERO);
        // Align camera
        cam.setRotation(spatial.getWorldRotation());
        cam.setLocation(spatial.getWorldTranslation().add(spatial.getWorldRotation().mult(translationOffset)));
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException("DelayedCamera cannot be cloned.");
    }
}
