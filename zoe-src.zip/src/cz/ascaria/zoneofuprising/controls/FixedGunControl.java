/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.controls;

import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import cz.ascaria.zoneofuprising.entities.ProjectileFactory;
import java.util.ArrayList;

/**
 *
 * @author Ascaria Quynn
 */
public class FixedGunControl extends ControlAdapter {

    protected ProjectileFactory projectileFactory;
    protected float projectileSpeed = 100f;
    protected int quantity = 0;

    protected ArrayList<Node> barrels = new ArrayList<Node>();

    /**
     * Adds barrel, it is location and rotation, where projectiles are created.
     * @param barrel 
     */
    public void addBarrel(Node barrel) {
        barrels.add(barrel);
    }

    /**
     * Adds ammunition to the turret.
     * @param barrel 
     */
    public void setProjectileFactory(ProjectileFactory projectileFactory, int quantity) {
        this.projectileFactory = projectileFactory;
        this.quantity = quantity;
    }

    /**
     * Returns number of remaining projectiles in the turret.
     * @return 
     */
    public int getRemainingProjectilesCount() {
        return quantity;
    }

    /**
     * Guns, guns, guns!
     */
    public void fire() {
        for(Node barrel : barrels) {
            fireFromBarrel(barrel);
        }
    }

    public void cease() {
        for(Node barrel : barrels) {
            ceaseFromBarrel(barrel);
        }
    }

    /**
     * Fire from one barrel.
     * @param barrel
     * @return was beam initiated?
     */
    protected boolean fireFromBarrel(Node barrel) {
        if(quantity > 0 && barrel.getQuantity() == 0) {
            // Poll beam
            Spatial beam = projectileFactory.createBeam();
            // Give beam parameters

            // Gimme fuel, Gimme fire, Gimme that which I desire, Ooh! 
            barrel.attachChild(beam);
            return true;
        }
        return false;
    }

    /**
     * Cease fire from one barrel.
     * @param barrel
     * @return was beam ceased?
     */
    protected boolean ceaseFromBarrel(Node barrel) {
        if(barrel.getQuantity() > 0) {
            barrel.detachAllChildren();
            return true;
        }
        return false;
    }
}
