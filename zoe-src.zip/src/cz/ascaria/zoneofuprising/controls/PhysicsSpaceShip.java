/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.controls;

import com.jme3.bullet.PhysicsSpace;
import com.jme3.bullet.PhysicsTickListener;
import com.jme3.bullet.collision.shapes.CollisionShape;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.math.Vector3f;

/**
 *
 * @author Ascaria Quynn
 */
abstract public class PhysicsSpaceShip extends RigidBodyControl implements PhysicsTickListener {

    protected PhysicsSpace physicsSpace = null;

    protected float movementPower = 1f;
    protected float rotationPower = 1f;

    protected Vector3f rotation = new Vector3f();
    protected Vector3f acceleration = new Vector3f();

    protected boolean rotationControl = false;
    protected boolean movementControl = false;

    // Used for getting isDrifting()
    public Vector3f nonFwdVel = new Vector3f();

    public PhysicsSpaceShip() {
    }

    public PhysicsSpaceShip(CollisionShape shape) {
        super(shape);
    }

    public PhysicsSpaceShip(CollisionShape shape, float mass) {
        super(shape, mass);
    }

    @Override
    public void setPhysicsSpace(PhysicsSpace space) {
        if(space == null) {
            if(this.space != null) {
                this.space.removeTickListener(this);
            }
        } else {
            if(this.space == space) {
                return;
            }
            space.addTickListener(this);
        }
        super.setPhysicsSpace(space);
    }

    public void setMovementPower(float movementPower) {
        this.movementPower = movementPower;
    }

    public void setRotationPower(float rotationPower) {
        this.rotationPower = rotationPower;
    }

    public void setMovementControl(boolean enabled) {
        movementControl = enabled;
    }

    public boolean isEnabledMovementControl() {
        return movementControl;
    }

    public Vector3f getAcceleration() {
        return acceleration;
    }

    public void setRotationControl(boolean enabled) {
        rotationControl = enabled;
        setAngularDamping(rotationControl ? 0.6f : 0f);
    }

    public boolean isEnabledRotationControl() {
        return rotationControl;
    }

    public Vector3f getRotation() {
        return rotation;
    }

    /**
     * Do ship any drifting?
     * @return 
     */
    public boolean isDrifting() {
        return nonFwdVel.length() > 0.03f;
    }

    /**
     * Method is called before each step, here you apply forces (change the state).
     * @param space
     * @param tpf 
     */
    public void prePhysicsTick(PhysicsSpace space, float tpf) {
        // Continuously compensate drifting, apply linear force (smoothly cancel sideways movement)
        if(movementControl && acceleration.x == 0f && acceleration.y == 0f) {
            Vector3f nVel = getLinearVelocity().normalize();
            Vector3f nDir = getPhysicsRotation().mult(Vector3f.UNIT_Z).normalizeLocal();
            nonFwdVel = nVel.subtract(nDir.mult(nVel.dot(nDir))).negateLocal()
                .multLocal(mass * movementPower * tpf);
            applyCentralForce(nonFwdVel);
            // TODO: pokud bude driftovani uplne minimalni,
            // rucne nastavit dopredny smer, aby nebylo zadny
        }

        // Apply linear speed force
        if(!acceleration.equals(Vector3f.ZERO)) {
            acceleration.normalizeLocal().multLocal(movementPower * mass * tpf);
            Vector3f finalAcceleration = getPhysicsRotation().mult(acceleration);
            applyCentralForce(finalAcceleration);
            acceleration.zero();
        }

        // Apply torque force
        if(!rotation.equals(Vector3f.ZERO)) {
            rotation.multLocal(movementPower * mass * tpf * 100f);
            applyTorque(getPhysicsRotation().mult(rotation));
            rotation.zero();
        }
    }

    /**
     * Method is called after each step, here you poll the results (get the current state).
     * @param space
     * @param tpf 
     */
    public void physicsTick(PhysicsSpace space, float tpf) {
        //System.out.println("I TICK!!!!");
    }
}
