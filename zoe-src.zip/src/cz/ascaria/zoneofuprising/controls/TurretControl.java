/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.controls;

import com.jme3.audio.AudioNode;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.math.FastMath;
import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import cz.ascaria.zoneofuprising.entities.ProjectileFactory;
import cz.ascaria.zoneofuprising.utils.NodeHelper;
import java.util.ArrayList;

/**
 *
 * @author Ascaria Quynn
 */
public class TurretControl extends ControlAdapter {

    // Misto parenta staci aktualizovat jeho world translation
    protected Node parent;
    protected RigidBodyControl parentRigidBody;
    // TODO: staci mi velocita a ne rigidbody
    protected Vector3f linearVelocity = new Vector3f();

    protected Node traverser;
    protected Node elevator;

    protected ArrayList<Node> barrels = new ArrayList<Node>();
    protected ProjectileFactory projectileFactory;
    protected float projectileSpeed = 100f;
    protected int quantity = 0;

    protected boolean fire = false;
    protected Geometry lockedTarget;
    protected AudioNode gunshotSound;

    protected float fireInitialCooldown = 0.3f;
    protected float fireActualCooldown = 0f;

    protected float tmpAngles[] = new float[3];

    /**
     * Set Parent Node and Control for getting location, velocity and rotation.
     * @param parent
     * @param parentRigidBody 
     */
    public void setParent(Node parent, RigidBodyControl parentRigidBody) {
        this.parent = parent;
        this.parentRigidBody = parentRigidBody;
    }

    /**
     * Set node which rotating turret horizontally.
     * @param traverser 
     */
    public void setTraverser(Node traverser) {
        this.traverser = traverser;
    }

    /**
     * Set node which rotating turret vertically.
     * @param elevator 
     */
    public void setElevator(Node elevator) {
        this.elevator = elevator;
    }

    /**
     * Adds barrel, it is location and rotation, where projectiles are created.
     * @param barrel 
     */
    public void addBarrel(Node barrel) {
        barrels.add(barrel);
    }

    /**
     * Adds ammunition to the turret.
     * @param barrel 
     */
    public void setProjectileFactory(ProjectileFactory projectileFactory, int quantity) {
        this.projectileFactory = projectileFactory;
        this.quantity = quantity;
        // Set sound of this ammunition
        this.gunshotSound = projectileFactory.createGunshotSound();
    }

    /**
     * Returns number of remaining projectiles in the turret.
     * @return 
     */
    public int getRemainingProjectilesCount() {
        return quantity;
    }

    /**
     * Guns, guns, guns!
     */
    public void fire() {
        this.fire = true;
    }

    /**
     * Cease fire!
     */
    public void cease() {
        this.fire = false;
    }

    /**
     * Is target locked?
     * @return 
     */
    public boolean isTargetLocked() {
        return null != lockedTarget;
    }

    /**
     * Locks barrels to the given geometry.
     * @param collision 
     */
    public void lockTarget(Geometry target) {
        lockedTarget = target;
        aim(lockedTarget);
    }

    /**
     * Aims barrels at locked target.
     * @param collision target may be Vector3f or null for reset
     */
    protected void aim(Geometry target) {
        if(null != target) {
            Vector3f predicted = predictLocation(target);
            // Get world up vector of the base
            Vector3f up = spatial.getWorldRotation().getRotationColumn(1);
            // Compute vertical + horizontal rotation
            elevator.lookAt(predicted, up);

            // Limit pitch and yaw
            float[] a = elevator.getLocalRotation().toAngles(null);
            // Pitch down
            if(a[0] > 7f * FastMath.DEG_TO_RAD) {
                a[0] = 7f * FastMath.DEG_TO_RAD;
            }
            // Pitch up
            if(a[0] < -35f * FastMath.DEG_TO_RAD) {
                a[0] = -35f * FastMath.DEG_TO_RAD;
            }
            // Yaw left
            if(a[1] > 20f * FastMath.DEG_TO_RAD) {
                a[1] = 20f * FastMath.DEG_TO_RAD;
            }
            // Yaw right
            if(a[1] < -20f * FastMath.DEG_TO_RAD) {
                a[1] = -20f * FastMath.DEG_TO_RAD;
            }
            elevator.setLocalRotation(new Quaternion().fromAngles(a));

            // Compute horizontal rotation
            if(null != traverser) {
                elevator.getLocalRotation().toAngles(tmpAngles);
                traverser.setLocalRotation(new Quaternion().fromAngleAxis(tmpAngles[1], Vector3f.UNIT_Y));
            }
        } else if(elevator.getLocalRotation() != Quaternion.IDENTITY) {
            elevator.setLocalRotation(Quaternion.IDENTITY);
            if(null != traverser) {
                traverser.setLocalRotation(Quaternion.IDENTITY);
            }
        }
    }

    @Override
    protected void controlUpdate(float tpf) {
        // Aim if target is locked
        if(isTargetLocked()) {
            aim(lockedTarget);
        }
        // Fire projectiles
        if(fire && fireActualCooldown <= 0f && !barrels.isEmpty()) {
            fireActualCooldown = fireInitialCooldown;
            for(Node barrel : barrels) {
                if(fireFromBarrel(barrel) && null != gunshotSound) {
                    gunshotSound.setTimeOffset(FastMath.nextRandomFloat() / 3f);
                    gunshotSound.playInstance();
                }
            }
        }
        // Do fire cooldown
        if(fireActualCooldown > 0f) {
            fireActualCooldown -= tpf;
        }
    }

    /**
     * Is turret at cooldown?
     * @return 
     */
    public boolean isCooldown() {
        return fireActualCooldown > 0f;
    }

    /**
     * Fire from one barrel.
     * @param barrel
     * @return was shot fired?
     */
    protected boolean fireFromBarrel(Node barrel) {
        if(quantity > 0 && null != parentRigidBody.getPhysicsSpace()) {
            // Poll projectile
            Spatial projectile = projectileFactory.createProjectile();
            quantity--;
            // Find local translation between barrel and parent node
            Vector3f barrelOffset = NodeHelper.getLocalTranslation(parent, barrel);
            // Set projectile transform
            ProjectileControl projectileControl = projectile.getControl(ProjectileControl.class);
            projectileControl.setPhysicsLocation(parentRigidBody.getPhysicsLocation().add(barrelOffset));
            projectileControl.setPhysicsRotation(barrel.getWorldRotation());
            // Give projectile velocity and direction
            Vector3f parentPhyVelocity = parentRigidBody.getLinearVelocity();
            Vector3f firingSpeed = barrel.getWorldRotation().mult(new Vector3f(0f, 0f, projectileSpeed));
            projectileControl.setLinearVelocity(parentPhyVelocity.add(firingSpeed));
            //projectileControl.setLinearDamping(0.9f);
            // Gimme fuel, Gimme fire, Gimme that which I desire, Ooh! 
            parentRigidBody.getPhysicsSpace().add(projectileControl);
            barrel.attachChild(projectile);
            return true;
        }
        return false;
    }

    /**
     * Predicts location of target in future.
     * @param target
     * @return 
     */
    protected Vector3f predictLocation(Geometry target) {
        // My velocity is added in fireFromBarrel, so here is 0
        linearVelocity.zero();
        // Try to get target's velocity
        RigidBodyControl rb = NodeHelper.tryFindRigidBody(target, 3);
        if(null != rb) {
            linearVelocity.addLocal(parentRigidBody.getLinearVelocity().subtract(rb.getLinearVelocity()));
        }
        // Compute needed lead offset
        float distance = NodeHelper.getLocalTranslation(target, parent).length();
        linearVelocity.multLocal(distance / (linearVelocity.length() + projectileSpeed));
        // Get predicted direction
        return target.getWorldTranslation().subtract(linearVelocity);
    }
}
