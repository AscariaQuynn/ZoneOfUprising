/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.controls;

import com.jme3.renderer.RenderManager;
import com.jme3.renderer.ViewPort;
import com.jme3.scene.control.AbstractControl;

/**
 *
 * @author Ascaria
 */
public abstract class ControlAdapter extends AbstractControl
{
    @Override
    protected void controlUpdate(float tpf)
    {
        // Do nothing
    }

    @Override
    protected void controlRender(RenderManager rm, ViewPort vp)
    {
        // Do nothing
    }
}
