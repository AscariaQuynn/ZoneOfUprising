/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.zoneofuprising.controls;

import com.jme3.asset.AssetManager;
import com.jme3.audio.AudioNode;
import com.jme3.bullet.collision.PhysicsCollisionEvent;
import com.jme3.bullet.collision.shapes.CollisionShape;
import com.jme3.math.FastMath;

/**
 *
 * @author Ascaria Quynn
 */
public class ProjectileControl extends BombControl {

    public AudioNode impactSound;

    public ProjectileControl(CollisionShape shape, float mass) {
        super(shape, mass);
    }


    public ProjectileControl(AssetManager manager, CollisionShape shape, float mass) {
        super(manager, shape, mass);
    }

    @Override
    public void collision(PhysicsCollisionEvent event) {
        if(null != impactSound && null != space && (event.getObjectA() == this || event.getObjectB() == this)) {
            impactSound.setTimeOffset(FastMath.nextRandomFloat() / 3f);
            impactSound.playInstance();
        }
        super.collision(event);
    }
}
