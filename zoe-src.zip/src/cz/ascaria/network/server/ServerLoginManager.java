/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.server;

import com.jme3.app.Application;
import com.jme3.app.state.AppStateManager;
import com.jme3.network.ConnectionListener;
import com.jme3.network.HostedConnection;
import com.jme3.network.Message;
import com.jme3.network.MessageListener;
import com.jme3.network.Network;
import com.jme3.network.Server;
import cz.ascaria.network.messages.ChatMessage;
import cz.ascaria.network.messages.CredentialsMessage;
import cz.ascaria.network.server.actions.CommandAction;
import cz.ascaria.network.server.actions.ExitAction;
import cz.ascaria.network.server.actions.InfoAction;
import cz.ascaria.network.server.actions.KickAction;
import cz.ascaria.zoneofuprising.appstates.BaseAppState;
import cz.ascaria.zoneofuprising.appstates.DebugAppState;
import cz.ascaria.zoneofuprising.appstates.FlyCamAppState;
import cz.ascaria.zoneofuprising.world.ServerWorldManager;
import java.io.IOException;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.concurrent.Callable;

/**
 *
 * @author Ascaria Quynn
 */
public class ServerLoginManager extends BaseAppState implements ConnectionListener, MessageListener<HostedConnection> {

    private Server server;
    private Console console;

    private ServerWorldManager worldManager;

    public void setConsole(Console console) {
        this.console = console;
    }

    /**
     * Run the server on specified port.
     * @param port
     * @throws IOException
     */
    public void runServer(int port) throws IOException {
        console.println("Creating server at port " + port);
        server = Network.createServer(port);
        server.addConnectionListener(this);
        server.addMessageListener(this,
            CredentialsMessage.class,
            ChatMessage.class
        );
        server.start();
        console.println("Server started successfully at " + InetAddress.getLocalHost() + " port " + port);
    }

    @Override
    public void initialize(AppStateManager stateManager, Application app) {
        super.initialize(stateManager, app);

        if(null == server || !server.isRunning()) {
            throw new IllegalStateException("You must use ServerLoginManager.runServer() first.");
        }

        console.addActionListener(new InfoAction(server));
        console.addActionListener(new ExitAction());
        console.addActionListener(new KickAction(server));
        console.addActionListener(new CommandAction(console, "Send"));

        // Create world
        //String world = "Scenes/Scene1/Scene1.j3o";
        String world = "Scenes/Uvod/level2.j3o";
        //String world = "Scenes/SpaceStation/SpaceStation.j3o";
        stateManager.attach(worldManager = new ServerWorldManager(server, world));

        // Fly by camera
        stateManager.attach(new FlyCamAppState());
        // Attach debug app state
        stateManager.attach(new DebugAppState());
    }

    @Override
    public void cleanup() {
        // Shutdown server
        if(null != server && server.isRunning()) {
            server.close();
        }
        // Shutdown console
        console.shutdown();
        // Shutdown world
        stateManager.detach(worldManager);
        worldManager = null;

        super.cleanup();
    }

    public void connectionAdded(Server server, final HostedConnection conn) {
        app.enqueue(new Callable() {
            public Object call() throws Exception {
                Console.sysprintln("Client " + conn.getId() + " connected at " + conn.getAddress());
                if(!worldManager.isWorldLoaded()) {
                    conn.close("World is not loaded.");
                }
                return null; 
            } 
        });
    }

    public void connectionRemoved(Server server, final HostedConnection conn) {
        app.enqueue(new Callable() {
            public Object call() throws Exception {
                Console.sysprintln("Client " + conn.getId() + " disconnected");
                String playerName = conn.getAttribute("name");
                worldManager.unloadClient(conn);
                return null; 
            } 
        });
    }

    public void messageReceived(final HostedConnection source, final Message m) {
        app.enqueue(new Callable() {
            public Object call() throws Exception {
                if(m instanceof ChatMessage) {
                    chatMessage(source, (ChatMessage)m);
                } else if(m instanceof CredentialsMessage) {
                    credentialsMessage(source, (CredentialsMessage)m);
                }
                return null; 
            } 
        });
    }

    public void credentialsMessage(final HostedConnection source, final CredentialsMessage m) {
        // Check if entity name already exist
        if(worldManager.entityExists(m.name)) {
            Console.sysprintln("Error: Client with name '" + m.name + "' already exists.");
            source.close("Error: Player with name '" + m.name + "' already exists.");
            return;
        }

        // Setup player's connection
        source.setAttribute("name", m.name);
        Console.sysprintln("Client " + source.getId() + " Received name: " + m.name);

        // Do authorization
        Console.sysprintln("Client " + source.getId() + " authorized successfully.");

        // Tell world manager what to load
        worldManager.loadClient(source);
    }

    public void chatMessage(HostedConnection source, ChatMessage m) {
        ChatMessage msg = new ChatMessage(source.getAttribute("name") + ": " + m.message);
        Console.sysprintln("Client " + source.getId() + " Chat: " + msg.message);
        server.broadcast(msg);
    }
}
