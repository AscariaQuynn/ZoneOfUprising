/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.server.actions;

import com.jme3.network.HostedConnection;
import com.jme3.network.Server;
import cz.ascaria.zoneofuprising.Main;
import cz.ascaria.zoneofuprising.utils.DateHelper;
import cz.ascaria.network.server.Console;
import java.awt.event.ActionEvent;
import java.util.logging.Level;
import javax.swing.AbstractAction;

/**
 *
 * @author Ascaria Quynn
 */
public class KickAction extends AbstractAction {

    private Server server;

    /**
     * @param name 
     */
    public KickAction(Server server) {
        this.server = server;
    }

    /**
     * @param event 
     */
    public void actionPerformed(ActionEvent event) {
        String command = event.getActionCommand();
        if(command.startsWith("/kick")) {
            try {
                int id = Integer.parseInt(command.substring(6));
                HostedConnection client = server.getConnection(id);
                if(null != client) {
                    client.close("Kicked");
                } else {
                    Console.sysprintln("Client with id " + id + " not found.");
                }
            } catch(NumberFormatException ex) {
                System.out.println(ex.getLocalizedMessage());
                Main.LOG.log(Level.SEVERE, null, ex);
            }
        }
    }
}
