/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.server.actions;

import com.jme3.network.Server;
import cz.ascaria.zoneofuprising.utils.DateHelper;
import cz.ascaria.network.server.Console;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

/**
 *
 * @author Ascaria Quynn
 */
public class InfoAction extends AbstractAction {

    private Server server;

    /**
     * @param console
     */
    public InfoAction(Server server) {
        this.server = server;
    }

    /**
     * @param event 
     */
    public void actionPerformed(ActionEvent event) {
        String command = event.getActionCommand();
        if(!command.isEmpty()) {
            if(command.equalsIgnoreCase("/help")) {
                Console.sysprintln("Commands: /help, /connections, /kick name, /exit");
            }
            if(command.equalsIgnoreCase("/connections")) {
                Console.sysprintln("Connected clients: " + server.getConnections().size());
            }
        }
    }
}
