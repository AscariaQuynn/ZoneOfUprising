/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.server.actions;

import cz.ascaria.zoneofuprising.Main;
import cz.ascaria.zoneofuprising.ZoneOfUprising;
import cz.ascaria.zoneofuprising.utils.DateHelper;
import cz.ascaria.network.server.Console;
import java.awt.event.ActionEvent;
import java.util.concurrent.TimeUnit;
import javax.swing.AbstractAction;

/**
 *
 * @author Ascaria Quynn
 */
public class ExitAction extends AbstractAction {

    public ExitAction() {
    }

    /**
     * @param event 
     */
    public void actionPerformed(ActionEvent event) {
        String command = event.getActionCommand();
        if(command.equalsIgnoreCase("/exit")) {
            Console.sysprintln("I should exit now, vydrž Prťka vydrž :)");
            // Non-blocking exit delay
            Main.executor.schedule(new Runnable() {
                public void run() {
                    System.exit(0);
                }
            }, 2, TimeUnit.SECONDS);
        }
    }
}
