/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.server.actions;

import cz.ascaria.network.server.Console;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

/**
 *
 * @author Ascaria Quynn
 */
public class CommandAction extends AbstractAction {

    private Console console;

    /**
     * @param console
     * @param name 
     */
    public CommandAction(Console console, String name) {
        super(name);
        this.console = console;
    }

    /**
     * @param event 
     */
    public void actionPerformed(ActionEvent event) {
        Console.clearInputText();
        String command = event.getActionCommand();
        if(!command.isEmpty()) {
            Console.sysprintln("Command: " + command);
        }
    }
}
