/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.sync;

import com.jme3.app.Application;
import com.jme3.app.state.AppStateManager;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.bullet.objects.PhysicsRigidBody;
import com.jme3.network.Message;
import com.jme3.network.Server;
import com.jme3.scene.Spatial;
import cz.ascaria.network.messages.ActionMessage;
import cz.ascaria.network.messages.AnalogMessage;
import cz.ascaria.network.messages.SyncMessage;
import cz.ascaria.network.server.Console;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.concurrent.Callable;

/**
 *
 * @author Ascaria Quynn
 */
public class ServerSyncManager extends BaseSyncManager {

    private LinkedList<AnalogMessage> analogMessageQueue = new LinkedList<AnalogMessage>();

    private float syncFrequency = 0.1f;
    private float syncTimer = 0f;

    private Server server;

    public ServerSyncManager(Server server) {
        this.server = server;
    }

    @Override
    public void initialize(AppStateManager stateManager, Application app) {
        super.initialize(stateManager, app);

        server.addMessageListener(this);

        Console.sysprintln("Server Sync Manager initialized");
    }

    @Override
    public void cleanup() {
        server.removeMessageListener(this);

        super.cleanup();
    }

    @Override
    public void update(float tpf) {
        super.update(tpf);

        // Apply received analog input from players
        for(Iterator<AnalogMessage> it = analogMessageQueue.iterator(); it.hasNext();) {
            applyAnalogMessage(it.next());
            it.remove();
        }

        // Send sync data by sync frequency
        syncTimer += tpf;
        if (syncTimer >= syncFrequency) {
            sendSyncData();
            syncTimer = 0;
        }
    }

    /**
     * Broadcast entities to clients.
     */
    public void sendSyncData() {
        for(Map.Entry<String, Spatial> entry : entities.entrySet()) {
            Spatial entity = entry.getValue();
            SyncMessage syncMessage = getEntitySyncMessage(entity);
            if(null != syncMessage) {
                // Set entity's name
                syncMessage.setEntityName(entry.getKey());
                // Read activation data
                boolean wasActive = entity.getUserData("entityWasActive");
                boolean isActive = entity.getUserData("entityIsActive");
                if(wasActive && !isActive) {
                    // If we want entity to stop, we send stop message
                    syncMessage.stopSyncData(entry.getValue());
                    server.broadcast(syncMessage);
                } else if(isActive) {
                    // If entity is active
                    syncMessage.readSyncData(entry.getValue());
                    server.broadcast(syncMessage);
                }
            }
        }
    }

    @Override
    public void messageReceived(Object source, final Message m) {
        super.messageReceived(source, m);

        app.enqueue(new Callable() {
            public Object call() throws Exception {
                if(m instanceof AnalogMessage) {
                    analogMessageQueue.add((AnalogMessage)m);
                }
                return null; 
            } 
        }); 
    }

    /**
     * Apply analog input on server.
     * @param m 
     */
    public void applyAnalogMessage(AnalogMessage m) {
        Spatial entity = entities.get(m.getEntityName());
        if(null != entity) {
            m.applyData(entity);
        }
    }

    /**
     * Apply action input.
     * @param m 
     */
    @Override
    public void applyActionMessage(ActionMessage m) {
        super.applyActionMessage(m);
        // Broadcast action input to all clients
        server.broadcast(m);
    }
}
