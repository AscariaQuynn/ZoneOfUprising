/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.sync;

import com.jme3.app.Application;
import com.jme3.app.state.AppStateManager;
import com.jme3.network.Client;
import com.jme3.network.Message;
import com.jme3.network.MessageListener;
import com.jme3.scene.Spatial;
import cz.ascaria.network.messages.SyncMessage;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.concurrent.Callable;

/**
 *
 * @author Ascaria Quynn
 */
public class ClientSyncManager extends BaseSyncManager implements MessageListener {

    private LinkedList<SyncMessage> syncMessageQueue = new LinkedList<SyncMessage>();

    private Client client;

    public ClientSyncManager(Client client) {
        this.client = client;
   }

    @Override
    public void initialize(AppStateManager stateManager, Application app) {
        super.initialize(stateManager, app);

        client.addMessageListener(this);
    }

    @Override
    public void cleanup() {
        client.removeMessageListener(this);

        super.cleanup();
    }

    @Override
    public void update(float tpf) {
        super.update(tpf);

        // Sync entities
        for(Iterator<SyncMessage> it = syncMessageQueue.iterator(); it.hasNext();) {
            syncEntity(it.next());
            it.remove();
        }
    }

    @Override
    public void messageReceived(Object source, final Message m) {
        super.messageReceived(source, m);

        app.enqueue(new Callable() {
            public Object call() throws Exception {
                if(m instanceof SyncMessage) {
                    syncMessageQueue.add((SyncMessage)m);
                }
                return null; 
            } 
        });
    }

    public void syncEntity(SyncMessage m) {
        Spatial entity = entities.get(m.getEntityName());
        if(null != entity) {
            m.applySyncData(entity);
        }
    }
}
