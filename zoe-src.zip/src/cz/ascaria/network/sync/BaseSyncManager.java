/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.sync;

import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.network.Message;
import com.jme3.network.MessageListener;
import com.jme3.scene.Spatial;
import cz.ascaria.network.messages.ActionMessage;
import cz.ascaria.network.messages.RigidBodySyncMessage;
import cz.ascaria.network.messages.ShipSyncMessage;
import cz.ascaria.network.messages.SyncMessage;
import cz.ascaria.zoneofuprising.appstates.BaseAppState;
import cz.ascaria.zoneofuprising.controls.SpaceShipControl;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.concurrent.Callable;

/**
 *
 * @author Ascaria Quynn
 */
public class BaseSyncManager extends BaseAppState implements MessageListener {
    
    protected HashMap<String, Spatial> entities = new HashMap<String, Spatial>();

    protected LinkedList<ActionMessage> actionMessageQueue = new LinkedList<ActionMessage>();

    private int newId = 0;

    /**
     * Add an entity to the list of entities managed by this sync manager.
     * @param entityName
     * @param spatial 
     */
    public boolean addEntity(String entityName, Spatial spatial) {
        if(isEntityValidForSyncing(spatial) && !entities.containsKey(entityName)) {
            entities.put(entityName, spatial);
            spatial.setUserData("entityName", entityName);
            spatial.setUserData("entityWasActive", false);
            spatial.setUserData("entityIsActive", false);
            return true;
        }
        return false;
    }

    /**
     * Add an entity to the list of entities managed by this sync manager. Entity's name is automatically generated.
     * @param spatial 
     */
    public String addEntity(Spatial spatial) {
        // Generate entity's name
        String name = "entity" + newId++;
        // Add entity to the list and inform caller about assigned entity name
        return addEntity(name, spatial) ? name : null;
    }

    /**
     * Removes an entity to the list of entities managed by this sync manager.
     * @param name 
     */
    public void removeEntity(String entityName) {
        if(entities.containsKey(entityName)) {
            entities.remove(entityName);
        }
    }

    /**
     * Is entity valid for syncing?
     * @param entity
     * @return
     * TODO: nekdy tohle a getEntitySyncMessage refaktorovat do entity managera
     */
    public boolean isEntityValidForSyncing(Spatial entity) {
        boolean isValid = false;
        if(null != entity.getControl(RigidBodyControl.class)) {
            isValid = true;
        }
        return isValid;
    }

    /**
     * Tries to create entity's sync message.
     * @param entityName
     * @return
     * TODO: nekdy tohle a isEntityValidForSyncing refaktorovat do entity managera
     */
    public SyncMessage getEntitySyncMessage(Spatial entity) {
        // Prepare activation data
        boolean isActive = entity.getUserData("entityIsActive");
        // TODO: nejak vymakat vytvareni sync message abych to nemusel ifovat
        SpaceShipControl spaceShipControl = entity.getControl(SpaceShipControl.class);
        if(null != spaceShipControl) {
            entity.setUserData("entityWasActive", isActive);
            entity.setUserData("entityIsActive", spaceShipControl.isActive());
            return new ShipSyncMessage();
        }
        RigidBodyControl rigidBodyControl = entity.getControl(RigidBodyControl.class);
        if(null != rigidBodyControl) {
            entity.setUserData("entityWasActive", isActive);
            entity.setUserData("entityIsActive", rigidBodyControl.isActive());
            return new RigidBodySyncMessage();
        }
        return null;
    }

    @Override
    public void update(float tpf) {
        super.update(tpf);

        // Apply received action input from players
        for(Iterator<ActionMessage> it = actionMessageQueue.iterator(); it.hasNext();) {
            applyActionMessage(it.next());
            it.remove();
        }
    }

    public void messageReceived(Object source, final Message m) {
        app.enqueue(new Callable() {
            public Object call() throws Exception {
                if(m instanceof ActionMessage) {
                    actionMessageQueue.add((ActionMessage)m);
                }
                return null; 
            } 
        }); 
    }

    /**
     * Apply action input.
     * @param m 
     */
    public void applyActionMessage(ActionMessage m) {
        Spatial entity = entities.get(m.getEntityName());
        if(null != entity) {
            m.applyActions(entity);
        }
    }
}
