/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.messages;

import com.jme3.network.Message;
import com.jme3.network.serializing.Serializable;
import com.jme3.scene.Spatial;

/**
 *
 * @author Ascaria Quynn
 */
@Serializable
public interface ActionMessage extends Message {

    public ActionMessage setEntityName(String entityName);

    public String getEntityName();

    public ActionMessage addAction(String name, String value);

    public boolean isEmpty();

    public void applyActions(Spatial entity);
}
