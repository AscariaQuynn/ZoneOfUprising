/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.messages;

import com.jme3.network.serializing.Serializable;
import com.jme3.scene.Spatial;
import cz.ascaria.zoneofuprising.controls.SpaceShipControl;

/**
 *
 * @author Ascaria Quynn
 */
@Serializable
public class ShipAnalogMessage extends BaseAnalogMessage {

    public float ascent = 0f;
    public float accelerate = 0f;
    public float strafe = 0f;

    public float yaw = 0f;
    public float roll = 0f;
    public float pitch = 0f;

    @Override
    public boolean isEmpty() {
        return ascent == 0f && accelerate == 0f && strafe == 0f && yaw == 0f && roll == 0f && pitch == 0f;
    }

    public void applyData(Spatial entity) {
        applyData(entity.getControl(SpaceShipControl.class));
    }

    public void applyData(SpaceShipControl shipControl) {
        shipControl.ascent(ascent);
        shipControl.accelerate(accelerate);
        shipControl.strafe(strafe);
        shipControl.yaw(yaw);
        shipControl.roll(roll);
        shipControl.pitch(pitch);
    }
}
