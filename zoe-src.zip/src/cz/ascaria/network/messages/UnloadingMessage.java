/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.messages;

import com.jme3.network.AbstractMessage;
import com.jme3.network.serializing.Serializable;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/**
 * Tells client what to unload.
 * @author Ascaria Quynn
 */
@Serializable
public class UnloadingMessage extends AbstractMessage {

    public List<List<String>> list = new LinkedList<List<String>>();

    /**
     * Sends client info about what to unload.
     * @param unload 
     */
    public UnloadingMessage() {
        super(true);
    }

    public UnloadingMessage add(String[] item) {
        list.add(Arrays.asList(item));
        return this;
    }
}
