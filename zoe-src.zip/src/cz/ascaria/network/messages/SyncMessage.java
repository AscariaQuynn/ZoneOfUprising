/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.messages;

import com.jme3.network.Message;
import com.jme3.scene.Spatial;

/**
 *
 * @author Ascaria Quynn
 */
public interface SyncMessage extends Message {

    public SyncMessage setEntityName(String entityName);

    public String getEntityName();

    public SyncMessage readSyncData(Spatial entity);

    public SyncMessage stopSyncData(Spatial entity);

    public void applySyncData(Spatial entity);
}
