/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.messages;

import com.jme3.math.Vector3f;
import com.jme3.network.serializing.Serializable;
import com.jme3.scene.Spatial;
import cz.ascaria.zoneofuprising.controls.SpaceShipControl;

/**
 * Sync message for physics objects (RigidBody).
 * @author normenhansen
 * @author Ascaria Quynn
 */
@Serializable()
public class ShipSyncMessage extends RigidBodySyncMessage {

    public Vector3f isAccelerating = new Vector3f();

    @Override
    public ShipSyncMessage readSyncData(Spatial body) {
        super.readSyncData(body);
        SpaceShipControl shipControl = body.getControl(SpaceShipControl.class);
        isAccelerating.set(shipControl.getIsAccelerating());
        // Fluent interface
        return this;
    }

    @Override
    public void applySyncData(Spatial body) {
        super.applySyncData(body);
        SpaceShipControl shipControl = body.getControl(SpaceShipControl.class);
        shipControl.setIsAccelerating(isAccelerating);
    }
}