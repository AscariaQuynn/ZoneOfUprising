/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.messages;

import com.jme3.network.AbstractMessage;
import com.jme3.network.serializing.Serializable;

/**
 *
 * @author Ascaria Quynn
 */
@Serializable
public class WorldLoadedMessage extends AbstractMessage {

    public String worldPath;

    public WorldLoadedMessage() {
        this("");
    }

    public WorldLoadedMessage(String worldPath) {
        super(true);
        this.worldPath = worldPath;
    }
}
