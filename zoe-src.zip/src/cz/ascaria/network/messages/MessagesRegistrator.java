/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.messages;

import com.jme3.network.serializing.Serializer;

/**
 *
 * @author Ascaria Quynn
 */
public class MessagesRegistrator {
    /**
     * Registers all messages.
     */
    public static void registerMessages() {
        // Login messages
        Serializer.registerClass(CredentialsMessage.class);

        // Loading & Unloading messages
        Serializer.registerClass(LoadingMessage.class);
        Serializer.registerClass(UnloadingMessage.class);
        Serializer.registerClass(WorldLoadedMessage.class);

        // Chat messages
        Serializer.registerClass(ChatMessage.class);

        // Sync messages
        Serializer.registerClass(RigidBodySyncMessage.class);
        Serializer.registerClass(ShipSyncMessage.class);

        // Analog & Action messages
        Serializer.registerClass(ShipAnalogMessage.class);
        Serializer.registerClass(ShipActionMessage.class);
    }
}
