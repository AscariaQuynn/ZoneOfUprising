/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.messages;

import com.jme3.network.AbstractMessage;
import com.jme3.network.serializing.Serializable;

/**
 *
 * @author Ascaria Quynn
 */
@Serializable
public class CredentialsMessage extends AbstractMessage {

    public String name;

    public CredentialsMessage() {
        this("");
    }

    /**
     * Used by client to tell server user's name.
     * @param name 
     */
    public CredentialsMessage(String name) {
        super(true);
        this.name = name;
    }
}
