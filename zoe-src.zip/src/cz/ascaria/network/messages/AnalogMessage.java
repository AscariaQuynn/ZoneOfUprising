/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.messages;

import com.jme3.network.Message;
import com.jme3.scene.Spatial;

/**
 *
 * @author Ascaria Quynn
 */
public interface AnalogMessage extends Message {

    public void setEntityName(String entityName);

    public String getEntityName();

    public boolean isEmpty();

    public void applyData(Spatial entity);
}
