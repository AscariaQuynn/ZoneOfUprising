/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.messages;

import com.jme3.network.AbstractMessage;

/**
 *
 * @author Ascaria Quynn
 */
abstract public class BaseSyncMessage extends AbstractMessage implements SyncMessage {

    protected String entityName = "";

    public BaseSyncMessage() {
        super(false);
    }

    public SyncMessage setEntityName(String entityName) {
        this.entityName = entityName;
        return this;
    }

    public String getEntityName() {
        return this.entityName;
    }
}
