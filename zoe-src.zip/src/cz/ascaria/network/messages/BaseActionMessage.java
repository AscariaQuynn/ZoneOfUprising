/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.messages;

import com.jme3.network.AbstractMessage;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Ascaria Quynn
 */
abstract public class BaseActionMessage extends AbstractMessage implements ActionMessage {

    protected String entityName = "";
    protected Map<String, String> actions = new HashMap<String, String>();

    public BaseActionMessage() {
        super(true);
    }

    public BaseActionMessage setEntityName(String entityName) {
        this.entityName = entityName;
        return this;
    }

    public String getEntityName() {
        return this.entityName;
    }

    public ActionMessage addAction(String name, String value) {
        actions.put(name, value);
        return this;
    }

    public boolean isEmpty() {
        return actions.isEmpty();
    }
}
