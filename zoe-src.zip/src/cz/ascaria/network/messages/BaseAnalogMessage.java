/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.messages;

import com.jme3.network.AbstractMessage;

/**
 *
 * @author Ascaria Quynn
 */
abstract public class BaseAnalogMessage extends AbstractMessage implements AnalogMessage {

    protected String entityName = "";

    public BaseAnalogMessage() {
        super(false);
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public String getEntityName() {
        return this.entityName;
    }
}
