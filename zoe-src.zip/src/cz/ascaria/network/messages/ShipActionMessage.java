/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.messages;

import com.jme3.network.serializing.Serializable;
import com.jme3.scene.Spatial;
import cz.ascaria.zoneofuprising.controls.SpaceShipControl;
import java.util.Map;

/**
 *
 * @author Ascaria Quynn
 */
@Serializable
public class ShipActionMessage extends BaseActionMessage {

    /**
     * Apply actions to ship.
     * @param ship 
     */
    public void applyActions(Spatial entity) {
        applyActions(entity.getControl(SpaceShipControl.class));
    }

    /**
     * Apply actions to ship.
     * @param shipControl 
     */
    public void applyActions(SpaceShipControl shipControl) {
        for(Map.Entry<String, String> action : actions.entrySet()) {
            if(action.getKey().equals("SwitchSpotLight")) {
                shipControl.switchSpotLights(action.getValue().equals("On"));
            }
            if(action.getKey().equals("SwitchPointLight")) {
                shipControl.switchPointLights(action.getValue().equals("On"));
            }
        }
    }
}
