/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.ascaria.network.client;

import cz.ascaria.network.messages.CredentialsMessage;
import com.jme3.app.Application;
import com.jme3.app.state.AppStateManager;
import com.jme3.math.FastMath;
import com.jme3.math.Vector2f;
import com.jme3.network.Client;
import com.jme3.network.ClientStateListener;
import com.jme3.network.Message;
import com.jme3.network.MessageListener;
import com.jme3.network.Network;
import cz.ascaria.network.messages.ChatMessage;
import cz.ascaria.network.messages.LoadingMessage;
import cz.ascaria.network.messages.UnloadingMessage;
import cz.ascaria.zoneofuprising.Main;
import cz.ascaria.zoneofuprising.ZoneOfUprising;
import cz.ascaria.zoneofuprising.appstates.BaseAppState;
import cz.ascaria.zoneofuprising.appstates.DebugAppState;
import cz.ascaria.zoneofuprising.appstates.JukeboxAppState;
import cz.ascaria.zoneofuprising.gui.GuiManager;
import cz.ascaria.zoneofuprising.gui.HudLayout;
import cz.ascaria.zoneofuprising.gui.Layout;
import cz.ascaria.zoneofuprising.gui.LayoutInitListener;
import cz.ascaria.zoneofuprising.gui.LoadingLayout;
import cz.ascaria.zoneofuprising.gui.MainMenuLayout;
import cz.ascaria.zoneofuprising.gui.ServerListLayout;
import cz.ascaria.zoneofuprising.gui.custom.DefaultAlertBox;
import cz.ascaria.zoneofuprising.world.ClientWorldManager;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.logging.Level;

/**
 *
 * @author Ascaria Quynn
 */
public class ClientLoginManager extends BaseAppState implements ClientStateListener, MessageListener<Client> {

    final public String playerName = System.getProperty("user.name") + FastMath.nextRandomInt(0, 3);
    
    public Client client;
    public GuiManager guiManager;

    private ClientWorldManager worldManager;

    @Override
    public void initialize(AppStateManager stateManager, Application app) {
        super.initialize(stateManager, app);
        System.out.println("ClientAppState.initialize() thread: " + Thread.currentThread());

        // Gui
        guiManager = new GuiManager((ZoneOfUprising)app, stateManager, ((ZoneOfUprising)app).getGuiNode());
        guiManager.initialize();
        guiManager.addLayoutInitialized(new LayoutInitListener() {
            public void layoutInitialized(Layout layout) {
                if(layout instanceof ServerListLayout) {
                    ((ServerListLayout)layout).clientLoginManager = ClientLoginManager.this;
                }
                if(layout instanceof HudLayout) {
                    ((HudLayout)layout).clientLoginManager = ClientLoginManager.this;
                }
            }
        });
        guiManager.show(MainMenuLayout.class);

        // Attach music state
        stateManager.attach(new JukeboxAppState());
        // Attach debug app state
        stateManager.attach(new DebugAppState());
    }

    @Override
    public void cleanup() {
        super.cleanup();

        // Shutdown gui
        guiManager.cleanup();
        guiManager = null;
        // Shutdown world
        stateManager.detach(worldManager);
        worldManager = null;
        // Shutdown connection
        if(null != client && client.isConnected()) {
            try {
                client.close();
            } catch(Exception e) {
                Main.LOG.log(Level.SEVERE, e.getMessage(), e);
            }
            client = null;
        }
    }

    /**
     * Create world.
     * @param worldPath
     * @param playerName
     */
    public void createWorld(String worldPath, String playerName) {
        stateManager.attach(worldManager = new ClientWorldManager(client, guiManager, worldPath, playerName));
    }

    /**
     * Destroy world.
     */
    public void destroyWorld() {
        stateManager.detach(worldManager);
        worldManager = null;
    }

    /**
     * Try to connect to the server.
     * @param hostName
     * @param hostPort
     * @throws IOException 
     */
    public void connect(String hostName, int hostPort) throws IOException {
        if(isConnected()) {
            throw new IllegalStateException("Client is connected.");
        }
        Client conn = Network.connectToServer(hostName, hostPort);
        conn.addClientStateListener(this);
        conn.addMessageListener(this,
            ChatMessage.class,
            LoadingMessage.class,
            UnloadingMessage.class
        );
        conn.start();
    }

    /**
     * Are we connected?
     * @return 
     */
    public boolean isConnected() {
        return null != client && client.isConnected();
    }

    /**
     * What to do after we are connected to the server.
     * @param c 
     */
    public void clientConnected(Client c) {
        // Save client
        client = c;
        // Send login message
        client.send(new CredentialsMessage(playerName));
        // Show loading layout
        app.enqueue(new Callable() {
            public Void call() throws Exception {
                if(isConnected()) {
                    guiManager.show(LoadingLayout.class);
                }
                return null;
            }
        });
    }

    /**
     * What to do after we are disconnected from the server.
     * @param c
     * @param info 
     */
    public void clientDisconnected(Client c, final DisconnectInfo info) {
        // Remove client
        client = null;
        // Print stack trace
        if(null != info && null != info.error) {
            Main.LOG.log(Level.SEVERE, info.error.getLocalizedMessage(), info.error);
        }
        // Return to menu
        app.enqueue(new Callable() {
            public Object call() throws Exception {
                destroyWorld();
                guiManager.show(ServerListLayout.class);
                if(null != info) {
                    DefaultAlertBox alert = new DefaultAlertBox(guiManager.screen, Vector2f.ZERO);
                    alert.setWindowTitle("Client disconnected");
                    alert.setMsg("Disconnected.\nReason: " + info.reason);
                    alert.showAsModal(false);
                    guiManager.screen.addElement(alert);
                    alert.centerToParent();
                }
                return null;
            }
        });
    }

    public void messageReceived(Client source, final Message m) {
        app.enqueue(new Callable() {
            public Object call() throws Exception {
                if(m instanceof ChatMessage) {
                    chatMessage((ChatMessage)m);
                } else if(m instanceof LoadingMessage) {
                    loadingMessage((LoadingMessage)m);
                } else if(m instanceof UnloadingMessage) {
                    unloadingMessage((UnloadingMessage)m);
                }
                return null; 
            } 
        });
    }

    public void chatMessage(final ChatMessage m) {
        HudLayout layout = (HudLayout)guiManager.getLayout(HudLayout.class);
        layout.receiveMsg(m.message);
    }


    public void loadingMessage(final LoadingMessage m) {
        for(List<String> i : m.list) {
            // Create and load world
            if(i.get(0).equals("world")) {
                createWorld(i.get(1), playerName);
            }
            // Load ship
            if(i.get(0).equals("entity")) {
                worldManager.loadEntity(i.get(1), i.get(2));
            }
        }
    }

    public void unloadingMessage(final UnloadingMessage m) {
        for(List<String> i : m.list) {
            if(i.get(0).equals("world")) {
                destroyWorld();
            }
            if(i.get(0).equals("entity")) {
                worldManager.unloadEntity(i.get(1));
            }
        }
    }
}
